package com.example.dynamicisland

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Builds the view + target size for each [IslandState]. Sizes (dp) were measured off the reference video. */
object Content {
    private val GREEN = 0xFF30D158.toInt()
    private val RED = 0xFFFF453A.toInt()
    private val ORANGE = 0xFFFF9F0A.toInt()
    private val PURPLE = 0xFF7D7AFF.toInt()
    private val YELLOW = 0xFFFFD60A.toInt()
    private val GRAY = 0xFF8E8E93.toInt()

    private const val V_START = Gravity.CENTER_VERTICAL or Gravity.START
    private const val V_END = Gravity.CENTER_VERTICAL or Gravity.END
    private const val WRAP = FrameLayout.LayoutParams.WRAP_CONTENT

    fun build(ctx: Context, s: IslandState, expanded: Boolean, c: IslandController): Spec = when (s) {
        is IslandState.Unlock -> unlock(ctx)
        is IslandState.Ringer ->
            if (s.silent) glyphText(ctx, Glyph.BELL_SLASH, ORANGE, "Silent", ORANGE, 220f, true)
            else glyphText(ctx, Glyph.BELL, Color.WHITE, "Ring", Color.WHITE, 220f, true)
        is IslandState.Battery -> battery(ctx, s)
        is IslandState.Volume -> volume(ctx, s)
        is IslandState.NotificationPreview -> notification(ctx, s, expanded)
        is IslandState.Dnd ->
            glyphText(ctx, Glyph.MOON, PURPLE, if (s.on) "On" else "Off", Color.WHITE, 210f, false)
        is IslandState.Torch ->
            glyphText(ctx, Glyph.FLASHLIGHT, if (s.on) YELLOW else GRAY, if (s.on) "On" else "Off", Color.WHITE, 210f, false)
        is IslandState.FaceId -> faceId(ctx)
        is IslandState.Buds -> buds(ctx)
        is IslandState.ScreenRec -> screenRec(ctx, s)
        is IslandState.VoiceRec -> voiceRec(ctx, s, expanded)
        is IslandState.Media -> if (expanded) mediaExpanded(ctx, s) else mediaCompact(ctx, s)
        is IslandState.Timer -> if (expanded) timerExpanded(ctx, s, c) else timerCompact(ctx, s)
        is IslandState.TimerDone -> glyphText(ctx, Glyph.BELL, ORANGE, "Time's up", ORANGE, 240f, true)
        is IslandState.Navigation -> navigation(ctx, s, expanded)
        is IslandState.Stopwatch -> stopwatch(ctx, s, expanded)
        is IslandState.Incoming -> incoming(ctx, s, c)
        is IslandState.Ongoing -> if (expanded) ongoingExpanded(ctx, s, c) else ongoingCompact(ctx, s)
    }


    private fun navigation(ctx: Context, s: IslandState.Navigation, expanded: Boolean): Spec {
        val f = FrameLayout(ctx)
        val arrow = GlyphView(ctx, Glyph.PLAY, 0xFF30D158.toInt())
        f.addAt(arrow, ctx.dpi(20f), ctx.dpi(20f), Gravity.CENTER_VERTICAL or Gravity.START, ml = ctx.dpi(16f))
        if (expanded) {
            f.addAt(text(ctx, s.instruction, 14f, Color.WHITE), ctx.dpi(270f), WRAP,
                Gravity.TOP or Gravity.START, ml = ctx.dpi(48f), mt = ctx.dpi(14f))
            f.addAt(text(ctx, "${s.distance} · ${s.eta}", 12f, 0xFFB8B8BE.toInt(), false),
                ctx.dpi(270f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(48f), mt = ctx.dpi(39f))
            return Spec(ctx.dpi(340f), ctx.dpi(82f), radius(ctx, 82f), f)
        }
        f.addAt(text(ctx, s.distance, 13f, Color.WHITE), WRAP, WRAP, Gravity.CENTER_VERTICAL or Gravity.END, mr = ctx.dpi(16f))
        return Spec(ctx.dpi(190f), ctx.dpi(42f), radius(ctx, 42f), f)
    }

    private fun stopwatch(ctx: Context, s: IslandState.Stopwatch, expanded: Boolean): Spec {
        val elapsed = s.accumulatedMs + if (s.running) SystemClock.elapsedRealtime() - s.startedAt else 0L
        val total = elapsed.coerceAtLeast(0L) / 1000L
        val label = "%02d:%02d".format(total / 60L, total % 60L)
        val f = FrameLayout(ctx)
        f.addAt(text(ctx, if (expanded) "STOPWATCH" else label, 11f, GRAY),
            WRAP, WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(16f), mt = ctx.dpi(8f))
        f.addAt(text(ctx, label, if (expanded) 26f else 14f, Color.WHITE),
            WRAP, WRAP, Gravity.BOTTOM or Gravity.END, mr = ctx.dpi(16f), mb = ctx.dpi(7f))
        return if (expanded) Spec(ctx.dpi(240f), ctx.dpi(78f), radius(ctx, 78f), f)
            else Spec(ctx.dpi(156f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    // ---------- helpers ----------

    private fun text(ctx: Context, str: String, sp: Float, color: Int, bold: Boolean = true) = TextView(ctx).apply {
        text = str
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        includeFontPadding = false
        maxLines = 1
    }

    private fun FrameLayout.addAt(
        v: View, w: Int, h: Int, gravity: Int,
        ml: Int = 0, mr: Int = 0, mt: Int = 0, mb: Int = 0
    ) {
        addView(v, FrameLayout.LayoutParams(w, h, gravity).apply {
            leftMargin = ml; rightMargin = mr; topMargin = mt; bottomMargin = mb
        })
    }

    /** Horizontal row; each child keeps whatever size its layoutParams already say (WRAP if none). */
    private fun cluster(ctx: Context, gapDp: Float, vararg views: View): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        views.forEachIndexed { i, v ->
            val lp = LinearLayout.LayoutParams(v.layoutParams?.width ?: WRAP, v.layoutParams?.height ?: WRAP)
            if (i > 0) lp.leftMargin = ctx.dpi(gapDp)
            l.addView(v, lp)
        }
        return l
    }

    private fun sized(v: View, w: Int, h: Int): View {
        v.layoutParams = LinearLayout.LayoutParams(w, h)
        return v
    }

    private fun circleBtn(
        ctx: Context, bg: Int, glyph: Glyph, tint: Int, sizeDp: Float, rot: Float = 0f, onClick: () -> Unit
    ): FrameLayout {
        val f = FrameLayout(ctx)
        f.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
        val g = GlyphView(ctx, glyph, tint)
        g.rotation = rot
        f.addView(g, FrameLayout.LayoutParams(ctx.dpi(sizeDp * 0.5f), ctx.dpi(sizeDp * 0.5f), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        return f
    }

    private fun artView(ctx: Context, bmp: Bitmap?, radiusDp: Float): ImageView {
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (bmp != null) {
            iv.setImageBitmap(bmp)
        } else {
            iv.setImageDrawable(
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFA586A.toInt(), 0xFFFA233B.toInt()))
            )
        }
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, ctx.dp(radiusDp))
            }
        }
        iv.clipToOutline = true
        return iv
    }

    private fun mmss(ms: Long, roundUp: Boolean): String {
        val total = if (roundUp) (ms + 999) / 1000 else ms / 1000
        val t = max(0L, total)
        return "%d:%02d".format(t / 60, t % 60)
    }

    private fun radius(ctx: Context, hDp: Float) = ctx.dp(min(hDp / 2f, 44f))

    // ---------- compact one-line pills ----------

    private fun unlock(ctx: Context): Spec {
        val f = FrameLayout(ctx)
        val g = GlyphView(ctx, Glyph.LOCK, Color.WHITE)
        f.addAt(g, ctx.dpi(16f), ctx.dpi(16f), Gravity.CENTER)
        g.postDelayed({
            g.glyph = Glyph.UNLOCK
            g.invalidate()
            g.animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).withEndAction {
                g.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }.start()
        }, 350)
        return Spec(ctx.dpi(126f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun glyphText(
        ctx: Context, glyph: Glyph, gTint: Int, label: String, tTint: Int, wDp: Float, wiggle: Boolean
    ): Spec {
        val f = FrameLayout(ctx)
        val g = GlyphView(ctx, glyph, gTint)
        f.addAt(g, ctx.dpi(20f), ctx.dpi(20f), V_START, ml = ctx.dpi(16f))
        f.addAt(text(ctx, label, 14f, tTint), WRAP, WRAP, V_END, mr = ctx.dpi(18f))
        if (wiggle) {
            ObjectAnimator.ofFloat(g, "rotation", 0f, -18f, 18f, -12f, 12f, 0f).apply {
                startDelay = 250
                duration = 600
                start()
            }
        }
        return Spec(ctx.dpi(wDp), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun battery(ctx: Context, s: IslandState.Battery): Spec {
        val color = if (s.charging) GREEN else RED
        val f = FrameLayout(ctx)
        f.addAt(text(ctx, if (s.charging) "Charging" else "Low Battery", 13f, Color.WHITE), WRAP, WRAP, V_START, ml = ctx.dpi(18f))
        val pct = text(ctx, "${s.level}%", 13f, color)
        val bat = BatteryView(ctx, s.level, color)
        bat.layoutParams = LinearLayout.LayoutParams(ctx.dpi(26f), ctx.dpi(13f))
        f.addAt(cluster(ctx, 6f, pct, bat), WRAP, WRAP, V_END, mr = ctx.dpi(16f))
        return Spec(ctx.dpi(252f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun volume(ctx: Context, s: IslandState.Volume): Spec {
        val f = FrameLayout(ctx)
        val pct = if (s.max > 0) (s.level * 100 / s.max).coerceIn(0, 100) else 0
        f.addAt(text(ctx, s.stream, 13f, Color.WHITE), WRAP, WRAP, V_START, ml = ctx.dpi(16f))
        val track = FrameLayout(ctx)
        track.background = GradientDrawable().apply { setColor(0xFF48484A.toInt()); cornerRadius = ctx.dp(4f) }
        val fill = View(ctx)
        fill.background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = ctx.dp(4f) }
        track.addView(fill, FrameLayout.LayoutParams(
            (ctx.dpi(92f) * pct / 100f).toInt().coerceAtLeast(ctx.dpi(2f)),
            FrameLayout.LayoutParams.MATCH_PARENT, Gravity.START
        ))
        f.addAt(track, ctx.dpi(92f), ctx.dpi(6f), V_END, mr = ctx.dpi(16f))
        return Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun notification(ctx: Context, s: IslandState.NotificationPreview, expanded: Boolean): Spec {
        val f = FrameLayout(ctx)
        val app = text(ctx, s.app.ifBlank { "Notification" }, 11f, GRAY)
        val title = text(ctx, s.title.ifBlank { "New notification" }, 14f, Color.WHITE)
        title.maxLines = if (expanded) 2 else 1
        val message = text(ctx, s.message, 12f, 0xFFD1D1D6.toInt(), false)
        message.maxLines = if (expanded) 2 else 1
        f.setOnClickListener { try { s.launch?.send() } catch (_: Exception) { } }
        if (expanded) {
            f.addAt(app, ctx.dpi(320f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(18f), mt = ctx.dpi(14f))
            f.addAt(title, ctx.dpi(320f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(18f), mt = ctx.dpi(34f))
            f.addAt(message, ctx.dpi(320f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(18f), mt = ctx.dpi(58f))
            return Spec(ctx.dpi(356f), ctx.dpi(92f), radius(ctx, 92f), f)
        }
        f.addAt(app, ctx.dpi(145f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(16f), mt = ctx.dpi(5f))
        f.addAt(title, ctx.dpi(145f), WRAP, Gravity.BOTTOM or Gravity.START, ml = ctx.dpi(16f), mb = ctx.dpi(5f))
        return Spec(ctx.dpi(230f), ctx.dpi(48f), radius(ctx, 48f), f)
    }

    private fun faceId(ctx: Context): Spec {
        val f = FrameLayout(ctx)
        val g = GlyphView(ctx, Glyph.FACE, Color.WHITE)
        f.addAt(g, ctx.dpi(20f), ctx.dpi(20f), Gravity.CENTER)
        g.postDelayed({
            g.glyph = Glyph.CHECK
            g.tint = GREEN
            g.invalidate()
            g.scaleX = 0.6f; g.scaleY = 0.6f
            g.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
        }, 750)
        return Spec(ctx.dpi(150f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun buds(ctx: Context): Spec {
        val f = FrameLayout(ctx)
        f.addAt(GlyphView(ctx, Glyph.HEADPHONES, Color.WHITE), ctx.dpi(22f), ctx.dpi(22f), V_START, ml = ctx.dpi(16f))
        val ring = RingView(ctx, Color.WHITE, 0f, 2.4f)
        f.addAt(ring, ctx.dpi(20f), ctx.dpi(20f), V_END, mr = ctx.dpi(16f))
        ring.postDelayed({ ring.sweepTo(1f, 700) }, 250)
        return Spec(ctx.dpi(230f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    // ---------- screen recording (demo only: Android exposes no public API for it) ----------

    private fun screenRec(ctx: Context, s: IslandState.ScreenRec): Spec {
        val f = FrameLayout(ctx)
        return when (s.phase) {
            0 -> {
                val ring = RingView(ctx, Color.WHITE, 0f, 2.4f)
                f.addAt(ring, ctx.dpi(20f), ctx.dpi(20f), V_START, ml = ctx.dpi(16f))
                ring.postDelayed({ ring.sweepTo(1f, 2600) }, 100)
                Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
            }
            1 -> {
                f.addAt(dot(ctx), ctx.dpi(10f), ctx.dpi(10f), V_START, ml = ctx.dpi(18f))
                val t = text(ctx, "0:00", 13f, RED)
                t.every(250) { t.text = mmss(SystemClock.elapsedRealtime() - s.startMs, false) }
                f.addAt(t, WRAP, WRAP, V_END, mr = ctx.dpi(18f))
                Spec(ctx.dpi(160f), ctx.dpi(37f), ctx.dp(18.5f), f)
            }
            else -> {
                f.addAt(dot(ctx), ctx.dpi(9f), ctx.dpi(9f), Gravity.TOP or Gravity.START, ml = ctx.dpi(22f), mt = ctx.dpi(15f))
                f.addAt(text(ctx, "00:03", 12f, RED), WRAP, WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(36f), mt = ctx.dpi(12f))
                f.addAt(text(ctx, "Recording Saved to Photos", 15f, Color.WHITE), WRAP, WRAP, Gravity.BOTTOM or Gravity.START, ml = ctx.dpi(22f), mb = ctx.dpi(12f))
                val icon = FrameLayout(ctx)
                icon.background = GradientDrawable().apply { setColor(0xFF2C7CF6.toInt()); cornerRadius = ctx.dp(10f) }
                f.addAt(icon, ctx.dpi(34f), ctx.dpi(34f), V_END, mr = ctx.dpi(20f))
                Spec(ctx.dpi(366f), ctx.dpi(76f), radius(ctx, 76f), f)
            }
        }
    }

    private fun dot(ctx: Context): View = View(ctx).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(RED) }
    }

    // ---------- voice recording ----------

    private fun voiceRec(ctx: Context, s: IslandState.VoiceRec, expanded: Boolean): Spec {
        val f = FrameLayout(ctx)
        val t = text(ctx, "00:00", if (expanded) 14f else 12f, RED)
        t.every(250) { t.text = "00:%02d".format(((SystemClock.elapsedRealtime() - s.startMs) / 1000) % 60) }
        val ringSize = if (expanded) 28f else 18f
        val stop = FrameLayout(ctx)
        stop.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
            setStroke(ctx.dpi(2f), Color.WHITE)
        }
        val inner = View(ctx)
        inner.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(RED) }
        stop.addView(inner, FrameLayout.LayoutParams(ctx.dpi(ringSize * 0.5f), ctx.dpi(ringSize * 0.5f), Gravity.CENTER))
        val right = cluster(ctx, 10f, t, sized(stop, ctx.dpi(ringSize), ctx.dpi(ringSize)))
        f.addAt(right, WRAP, WRAP, V_END, mr = ctx.dpi(if (expanded) 18f else 14f))
        val barsW = if (expanded) 140f else 34f
        f.addAt(BarsView(ctx, if (expanded) 36 else 9, 2f, 2f, RED), ctx.dpi(barsW), ctx.dpi(if (expanded) 22f else 14f), V_START, ml = ctx.dpi(if (expanded) 20f else 16f))
        return if (expanded) Spec(ctx.dpi(346f), ctx.dpi(52f), ctx.dp(26f), f)
        else Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    // ---------- music ----------

    private fun mediaCompact(ctx: Context, s: IslandState.Media): Spec {
        val f = FrameLayout(ctx)
        f.addAt(artView(ctx, s.art, 6f), ctx.dpi(24f), ctx.dpi(24f), V_START, ml = ctx.dpi(8f))
        f.addAt(BarsView(ctx, 4, 3f, 2.5f, Color.WHITE, s.playing), ctx.dpi(24f), ctx.dpi(18f), V_END, mr = ctx.dpi(16f))
        return Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun mediaExpanded(ctx: Context, s: IslandState.Media): Spec {
        val f = FrameLayout(ctx)
        f.addAt(artView(ctx, s.art, 12f), ctx.dpi(64f), ctx.dpi(64f), Gravity.TOP or Gravity.START, ml = ctx.dpi(22f), mt = ctx.dpi(22f))
        f.addAt(text(ctx, s.title.ifBlank { "Not Playing" }, 16f, Color.WHITE), ctx.dpi(190f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(98f), mt = ctx.dpi(30f))
        f.addAt(text(ctx, s.artist, 14f, GRAY, false), ctx.dpi(190f), WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(98f), mt = ctx.dpi(54f))
        f.addAt(BarsView(ctx, 4, 3f, 2.5f, Color.WHITE, s.playing), ctx.dpi(24f), ctx.dpi(20f), Gravity.TOP or Gravity.END, mr = ctx.dpi(28f), mt = ctx.dpi(34f))

        val pv = ProgressView(ctx)
        f.addAt(pv, FrameLayout.LayoutParams.MATCH_PARENT, ctx.dpi(4f), Gravity.TOP, ml = ctx.dpi(24f), mr = ctx.dpi(24f), mt = ctx.dpi(100f))
        if (s.durationMs > 0) {
            pv.every(250) { pv.progress = s.position().toFloat() / s.durationMs.toFloat(); pv.invalidate() }
        }

        val prev = GlyphView(ctx, Glyph.PREV, Color.WHITE)
        val play = GlyphView(ctx, if (s.playing) Glyph.PAUSE else Glyph.PLAY, Color.WHITE)
        val next = GlyphView(ctx, Glyph.NEXT, Color.WHITE)
        prev.setOnClickListener { s.controls?.skipToPrevious() }
        next.setOnClickListener { s.controls?.skipToNext() }
        play.setOnClickListener { if (s.playing) s.controls?.pause() else s.controls?.play() }
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        for ((i, g) in listOf(prev, play, next).withIndex()) {
            val size = if (i == 1) 34f else 28f
            val lp = LinearLayout.LayoutParams(ctx.dpi(size), ctx.dpi(size))
            if (i > 0) lp.leftMargin = ctx.dpi(44f)
            row.addView(g, lp)
        }
        f.addAt(row, WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, mb = ctx.dpi(14f))
        return Spec(ctx.dpi(370f), ctx.dpi(170f), radius(ctx, 170f), f)
    }

    // ---------- timer ----------

    private fun remaining(t: IslandState.Timer): Long =
        t.pausedLeft ?: max(0L, t.endMs - SystemClock.elapsedRealtime())

    private fun timerCompact(ctx: Context, t: IslandState.Timer): Spec {
        val f = FrameLayout(ctx)
        val ring = RingView(ctx, ORANGE, 1f, 2.4f)
        f.addAt(ring, ctx.dpi(20f), ctx.dpi(20f), V_START, ml = ctx.dpi(14f))
        val tv = text(ctx, mmss(remaining(t), true), 13f, ORANGE)
        f.addAt(tv, WRAP, WRAP, V_END, mr = ctx.dpi(16f))
        tv.every(250) {
            val left = remaining(t)
            tv.text = mmss(left, true)
            ring.progress = left.toFloat() / t.totalMs.toFloat()
            ring.invalidate()
        }
        return Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun timerExpanded(ctx: Context, t: IslandState.Timer, c: IslandController): Spec {
        val f = FrameLayout(ctx)
        val pause = circleBtn(
            ctx, ORANGE, if (t.pausedLeft == null) Glyph.PAUSE else Glyph.PLAY, Color.BLACK, 50f
        ) { c.pauseResumeTimer() }
        val cancel = circleBtn(ctx, 0xFF3A3A3C.toInt(), Glyph.CLOSE, Color.WHITE, 50f) { c.cancelTimer() }
        f.addAt(pause, ctx.dpi(50f), ctx.dpi(50f), V_START, ml = ctx.dpi(14f))
        f.addAt(cancel, ctx.dpi(50f), ctx.dpi(50f), V_START, ml = ctx.dpi(72f))
        val label = text(ctx, "Timer", 13f, ORANGE)
        val time = text(ctx, mmss(remaining(t), true), 34f, ORANGE)
        time.every(250) { time.text = mmss(remaining(t), true) }
        f.addAt(cluster(ctx, 8f, label, time), WRAP, WRAP, V_END, mr = ctx.dpi(24f))
        return Spec(ctx.dpi(366f), ctx.dpi(78f), radius(ctx, 78f), f)
    }

    // ---------- calls ----------

    private fun incoming(ctx: Context, s: IslandState.Incoming, c: IslandController): Spec {
        val f = FrameLayout(ctx)
        val avatar = FrameLayout(ctx)
        avatar.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF636366.toInt()) }
        val initial = s.caller.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"
        avatar.addView(text(ctx, initial, 20f, Color.WHITE), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        f.addAt(avatar, ctx.dpi(50f), ctx.dpi(50f), V_START, ml = ctx.dpi(14f))
        f.addAt(text(ctx, "Incoming call", 12f, GRAY, false), WRAP, WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(74f), mt = ctx.dpi(15f))
        f.addAt(text(ctx, s.caller, 17f, Color.WHITE), ctx.dpi(150f), WRAP, Gravity.BOTTOM or Gravity.START, ml = ctx.dpi(74f), mb = ctx.dpi(15f))
        val decline = circleBtn(ctx, 0xFFFF3B30.toInt(), Glyph.PHONE, Color.WHITE, 50f, 135f) { c.declineCall() }
        val accept = circleBtn(ctx, 0xFF34C759.toInt(), Glyph.PHONE, Color.WHITE, 50f) { c.answerCall() }
        f.addAt(decline, ctx.dpi(50f), ctx.dpi(50f), V_END, mr = ctx.dpi(74f))
        f.addAt(accept, ctx.dpi(50f), ctx.dpi(50f), V_END, mr = ctx.dpi(14f))
        return Spec(ctx.dpi(366f), ctx.dpi(78f), radius(ctx, 78f), f)
    }

    private fun ongoingCompact(ctx: Context, s: IslandState.Ongoing): Spec {
        val f = FrameLayout(ctx)
        val t = text(ctx, "0:00", 13f, GREEN)
        t.every(500) { t.text = mmss(SystemClock.elapsedRealtime() - s.startMs, false) }
        val phone = GlyphView(ctx, Glyph.PHONE, GREEN)
        phone.layoutParams = LinearLayout.LayoutParams(ctx.dpi(16f), ctx.dpi(16f))
        f.addAt(cluster(ctx, 6f, phone, t), WRAP, WRAP, V_START, ml = ctx.dpi(14f))
        f.addAt(BarsView(ctx, 5, 2.5f, 2f, Color.WHITE), ctx.dpi(28f), ctx.dpi(16f), V_END, mr = ctx.dpi(16f))
        return Spec(ctx.dpi(190f), ctx.dpi(37f), ctx.dp(18.5f), f)
    }

    private fun ongoingExpanded(ctx: Context, s: IslandState.Ongoing, c: IslandController): Spec {
        val f = FrameLayout(ctx)
        f.addAt(text(ctx, "Mobile", 12f, GRAY, false), WRAP, WRAP, Gravity.TOP or Gravity.START, ml = ctx.dpi(24f), mt = ctx.dpi(15f))
        val t = text(ctx, "0:00", 22f, GREEN)
        t.every(500) { t.text = mmss(SystemClock.elapsedRealtime() - s.startMs, false) }
        f.addAt(t, WRAP, WRAP, Gravity.BOTTOM or Gravity.START, ml = ctx.dpi(24f), mb = ctx.dpi(14f))
        f.addAt(BarsView(ctx, 7, 3f, 3f, Color.WHITE), ctx.dpi(50f), ctx.dpi(24f), Gravity.CENTER)
        val end = circleBtn(ctx, 0xFFFF3B30.toInt(), Glyph.PHONE, Color.WHITE, 50f, 135f) { c.declineCall() }
        f.addAt(end, ctx.dpi(50f), ctx.dpi(50f), V_END, mr = ctx.dpi(14f))
        return Spec(ctx.dpi(366f), ctx.dpi(78f), radius(ctx, 78f), f)
    }
}
