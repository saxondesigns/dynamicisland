package com.kiwi.island

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class IslandViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val pinned = MutableStateFlow<String?>(null)

    val expanded = MutableStateFlow(false)
    val cutout = MutableStateFlow<CutoutInfo?>(null)

    val settings: StateFlow<IslandSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, IslandSettings())

    val activities: StateFlow<List<IslandActivity>> =
        combine(ActivityRepository.activities, settings, pinned) { all, s, pin ->
            val list = all.filter { it.category.name !in s.disabled }
            val first = list.firstOrNull { it.id == pin }
            if (first != null) listOf(first) + (list - first) else list
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun setExpanded(value: Boolean) {
        expanded.value = value
    }

    fun pin(id: String) {
        pinned.value = id
    }
}
