package com.kiwi.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowInsets
import android.view.WindowManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.lifecycle.ViewTreeViewModelStoreOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

class IslandService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owner = OverlayOwner()
    private val animX = Animatable(0f)
    private val animY = Animatable(0f)
    private lateinit var vm: IslandViewModel
    private lateinit var windowManager: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var view: ComposeView
    private var attached = false
    private var layoutJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running.value = true
        owner.create()
        vm = ViewModelProvider(owner, ViewModelProvider.AndroidViewModelFactory.getInstance(application))[IslandViewModel::class.java]

        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val windowContext = createDisplayContext(display)
            .createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
        windowManager = windowContext.getSystemService(WindowManager::class.java)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            title = "island"
        }

        view = ComposeView(windowContext).apply {
            ViewTreeLifecycleOwner.set(this, owner)
            ViewTreeSavedStateRegistryOwner.set(this, owner)
            ViewTreeViewModelStoreOwner.set(this, owner)
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) vm.setExpanded(false)
                false
            }
            setContent { Host() }
        }

        ChargingSource.start(this)
        CallSource.start(this)

        scope.launch {
            vm.settings.collect { settings ->
                place(settings)
                if (!attached) {
                    windowManager.addView(view, params)
                    owner.resume()
                    attached = true
                }
            }
        }
    }

    @Composable
    private fun Host() {
        val settings by vm.settings.collectAsState()
        val activities by vm.activities.collectAsState()
        val expanded by vm.expanded.collectAsState()
        val cutout by vm.cutout.collectAsState()
        IslandOverlay(
            settings = settings,
            activities = activities,
            expanded = expanded,
            cutout = cutout,
            onExpandedChange = vm::setExpanded,
            onPin = vm::pin,
            onOpen = { activity ->
                activity.open?.let { runCatching { it.send() } }
                vm.setExpanded(false)
            }
        )
    }

    private suspend fun place(s: IslandSettings) {
        val metrics = windowManager.currentWindowMetrics
        val insets = metrics.windowInsets
        val d = resources.displayMetrics.density
        val rect = insets.displayCutout?.boundingRectTop
        val statusTop = insets.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars()).top
        val targetX: Float
        val targetY: Float

        if (s.cameraAware && rect != null) {
            val info = CutoutInfo(rect.width() / d, rect.height() / d)
            vm.cutout.value = info
            val pillHeightPx = max(s.height, info.heightDp) * d
            targetY = (rect.exactCenterY() - pillHeightPx / 2f).coerceAtLeast(0f)
            targetX = rect.exactCenterX() - metrics.bounds.width() / 2f
        } else {
            vm.cutout.value = null
            targetY = (max(rect?.bottom ?: 0, statusTop) + s.margin * d)
            targetX = 0f
        }

        if (!attached) {
            animX.snapTo(targetX)
            animY.snapTo(targetY)
            params.x = targetX.roundToInt()
            params.y = targetY.roundToInt()
        }

        layoutJob?.cancel()
        layoutJob = scope.launch {
            launch {
                animY.animateTo(targetY, spring(dampingRatio = 0.85f, stiffness = 300f)) {
                    params.y = value.roundToInt()
                    refresh()
                }
            }
            vm.expanded.collectLatest { open ->
                animX.animateTo(if (open) 0f else targetX, spring(dampingRatio = 0.8f, stiffness = 380f)) {
                    params.x = value.roundToInt()
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        if (attached && view.isAttachedToWindow) windowManager.updateViewLayout(view, params)
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentTitle("Island is running")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    override fun onDestroy() {
        layoutJob?.cancel()
        scope.cancel()
        ChargingSource.stop(this)
        CallSource.stop(this)
        if (::view.isInitialized) {
            view.disposeComposition()
            if (attached) runCatching { windowManager.removeView(view) }
        }
        owner.destroy()
        running.value = false
        super.onDestroy()
    }

    companion object {
        val running = MutableStateFlow(false)

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, IslandService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, IslandService::class.java))
        }
    }
}
