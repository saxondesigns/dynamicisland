Island, a floating live-activity overlay for Android

Build: open in Android Studio (Ladybug or newer), let it sync, run on a physical device running Android 11 or newer.

Setup on the device
1. Allow "Display over other apps".
2. Allow notification access for Island (feeds media, navigation, delivery, downloads, notifications).
3. Allow phone state and call controls (calls).
4. On Android 13+, allow notifications so the service notification is visible.
5. Turn on "Show island".
Some manufacturers (Xiaomi, Oppo, Samsung, Huawei) kill background services aggressively. Exclude Island from battery optimisation and lock it in recents.

Adding an activity type
Create a class implementing IslandActivity (Leading, Trailing, Expanded, expandedHeight, priority, category), add a Category entry, and publish instances to ActivityRepository from any source.
