# Island Final — Android-native integrations

This project uses Android APIs for its live overlay and integrations.

## Native integrations in this edition
- Active media sessions are read through `MediaSessionManager`/`MediaController` (notification-listener access is required).
- Expanded music scrubbing seeks the real media session when metadata/duration and seek support are available. Demo music remains simulated.
- Timers use `AlarmManager` plus persisted wall-clock end time, so a timer can finish while the overlay service is not active. The receiver posts a native Android notification. A boot receiver reschedules an unexpired timer.
- Notification previews and actual notification-listener events feed the overlay.
- Overlay is an Android `TYPE_APPLICATION_OVERLAY`; Android does not expose Apple's private Dynamic Island/Live Activities UI.

## Setup
1. Build/install the APK.
2. In Island Lab, enable **Display over other apps** and **Notification access**.
3. Allow notifications if prompted (Android 13+).
4. Start a timer or open expanded media controls. Real seeking depends on the active media app supporting seeking.

## Limitations
- Split activity, call-style previews, and demo tracks are UI previews, not system Live Activities or a real incoming-call screen.
- Apps cannot answer/decline arbitrary incoming calls without special Telecom roles/permissions. The call preview does not place or answer calls.
- Timer alarm delivery is subject to Android power-management behavior; this build uses `setAndAllowWhileIdle`, not exact-alarm access.
- The project has not been built in this environment because Android SDK/Gradle are unavailable. Verify in GitHub Actions before installing.
