package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val service get() = IslandService.instance
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()


    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 3001)
        }
        val pad = dp(20)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF101114.toInt())
        }
        page.addView(TextView(this).apply {
            text = "ISLAND LAB\nTest controls & previews"
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt())
        }, margin(0, 0, 0, 8))
        page.addView(TextView(this).apply {
            text = "Enable the permissions below, then use the test buttons to preview each Island state."
            textSize = 14f; setTextColor(0xFFB8B8BD.toInt())
        }, margin(0, 0, 0, 18))

        section(page, "SETUP")
        addButton(page, "Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addButton(page, "Enable notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        section(page, "ISLAND PREVIEWS")
        addButton(page, "Preview standard notification") { serviceOrWarn()?.previewNotification() }
        addButton(page, "Preview message notification") { serviceOrWarn()?.previewNotification("Alex", "Hey! This is a sample message preview.") }
        addButton(page, "Preview download notification") { serviceOrWarn()?.previewNotification("Download complete", "Your file is ready to open.") }
        addButton(page, "Demo music island") { serviceOrWarn()?.previewMusic() }
        addButton(page, "Preview dual activity (music + timer)") { serviceOrWarn()?.previewDualActivity() }
        addButton(page, "Preview call-style controls (demo only)") { serviceOrWarn()?.previewCallAction() }
        addButton(page, "Expand current island") { serviceOrWarn()?.expandCurrent() }
        addButton(page, "Collapse island") { serviceOrWarn()?.collapseCurrent() }
        addButton(page, "Dismiss island") { serviceOrWarn()?.dismissIsland() }
        addButton(page, "Stop music demo") { serviceOrWarn()?.stopDemoMusic() }
        addButton(page, "Reset Island to idle") { serviceOrWarn()?.dismissIsland() }

        section(page, "TIMER TESTS")
        val seconds = EditText(this).apply {
            hint = "Timer duration in seconds (e.g. 10)"
            setText("10")
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF8B8B91.toInt())
            setSingleLine(true)
        }
        page.addView(seconds, margin(0, 4, 0, 8))
        addButton(page, "Start custom timer") {
            val value = seconds.text.toString().toIntOrNull()?.coerceIn(1, 86400)
            if (value == null) Toast.makeText(this, "Enter seconds between 1 and 86400", Toast.LENGTH_SHORT).show()
            else serviceOrWarn()?.startTimer(value)
        }
        addButton(page, "Start 10-second test timer") { serviceOrWarn()?.startTimer(10) }
        addButton(page, "Start 1-minute timer") { serviceOrWarn()?.startTimer(60) }
        addButton(page, "Cancel timer") { serviceOrWarn()?.dismissIsland() }

        section(page, "QUICK ANIMATION TEST")
        addButton(page, "Run notification transition test") {
            val s = serviceOrWarn() ?: return@addButton
            s.previewNotification("Animation test", "Checking Island transitions")
            Toast.makeText(this, "Tap the Island to inspect its transition", Toast.LENGTH_SHORT).show()
        }
        addButton(page, "Run dual activity transition") { serviceOrWarn()?.previewDualActivity() }
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun serviceOrWarn(): IslandService? = service ?: run {
        Toast.makeText(this, "Enable Notification Access, then return here. If still unavailable, reopen the app.", Toast.LENGTH_LONG).show()
        null
    }
    private fun section(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label; textSize = 12f; setTextColor(0xFF8D8D98.toInt())
        }, margin(0, 18, 0, 8))
    }
    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } }, margin(0, 2, 0, 6))
    }
    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(dp(l), dp(t), dp(r), dp(b))
    }
}
