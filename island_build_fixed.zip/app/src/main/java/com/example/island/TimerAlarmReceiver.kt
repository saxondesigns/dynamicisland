package com.example.island

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Android-native alarm/notification fallback so the timer can finish even if the overlay service is not active. */
class TimerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("island_timer", Context.MODE_PRIVATE)
        val end = prefs.getLong("end", 0L)
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            if (end > System.currentTimeMillis()) {
                val pi = PendingIntent.getBroadcast(context, 901, Intent(context, TimerAlarmReceiver::class.java).setAction(ACTION_TIMER_DONE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            }
            return
        }
        if (intent?.action != ACTION_TIMER_DONE || end == 0L || end > System.currentTimeMillis()) return
        prefs.edit().remove("end").apply()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Island timer", NotificationManager.IMPORTANCE_HIGH))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL) else Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Timer finished")
            .setContentText("Your timer is complete.")
            .setAutoCancel(true)
        manager.notify(NOTIFICATION_ID, notification.build())
    }
    companion object {
        const val ACTION_TIMER_DONE = "com.example.island.TIMER_DONE"
        private const val CHANNEL = "island_timer_finished"
        private const val NOTIFICATION_ID = 902
    }
}
