# Dynamic Island for Android

An Android re-creation of the iPhone 15 Dynamic Island animations from the reference
video: a black pill over the camera cutout that springs between compact and expanded
shapes for each system event.

**Build:** push to GitHub. `.github/workflows/android.yml` compiles the project and
uploads `dynamic-island-debug-apk` as a build artifact. Install that APK, open the app,
then:

1. Tap **Allow "Display over other apps"** (required, draws the island).
2. Tap **Allow media access** and enable *Dynamic Island media* (music island).
3. Tap **Allow phone, contacts, Bluetooth, notifications** (calls, headphones).
4. Tap **Start island**, then try any demo button.

Requires Android 8.0+ (API 26). Debug APK only; no signing config is included.

## What triggers each animation

| Video state            | Real trigger on Android                                   | Demo button |
|------------------------|-----------------------------------------------------------|-------------|
| Unlock                 | `ACTION_USER_PRESENT`                                     | yes |
| Ring / Silent          | `RINGER_MODE_CHANGED_ACTION`                              | yes |
| Charging               | `ACTION_POWER_CONNECTED`                                  | yes |
| Low battery            | `ACTION_BATTERY_LOW`                                      | yes |
| Do Not Disturb         | `ACTION_INTERRUPTION_FILTER_CHANGED`                      | yes |
| Flashlight             | `CameraManager.TorchCallback`                             | yes |
| Voice recording        | `AudioManager.AudioRecordingCallback`                     | yes |
| Headphones connected   | `BluetoothDevice.ACTION_ACL_CONNECTED` (audio devices)    | yes |
| Music                  | `MediaSessionManager` via a notification listener         | yes |
| Incoming / ongoing call| `ACTION_PHONE_STATE_CHANGED`; accept/decline via Telecom  | yes |
| Timer                  | **Demo only** (the Clock app exposes no public API)       | yes |
| Screen recording       | **Demo only** (no public API)                             | yes |
| Face ID                | **Demo only** (Android has no global face-unlock hook)    | yes |

## Design decisions (why the code is the way it is)

* **Plain Views + `SpringAnimation`, no Compose.** An overlay window has no
  Activity lifecycle, and hosting Compose in one needs hand-built lifecycle owners, a
  common source of crashes. Views are the reliable choice for a `WindowManager` overlay.
* **Three springs (width, height, corner radius).** The real island's character is a
  slight overshoot-and-settle. `IslandView.STIFFNESS` / `DAMPING` are the two numbers
  to tune.
* **Content is clipped to the pill and fades in with scale + blur** while the shape
  morphs underneath (blur needs Android 12+; older versions just skip it).
* **Window is sized to the island, not full width.** An overlay swallows touches in its
  whole rectangle, so a full-width window would block the status bar. The window is
  resized to the target island (plus 16dp spring margin) and removed when idle.
* **Positioned from the real camera cutout** (`DisplayCutout.boundingRectTop`, API 30+),
  falling back to top-centre, 126x37dp, 11dp down on older phones or phones without a
  top cutout.
* **Two layers of state** (`IslandController`): brief transient events on top, and
  persistent "live activities" underneath with priority call > recording > timer > music.
* **No Gradle wrapper jar is committed.** CI installs Gradle 8.7 directly, so the repo
  has no binary files. To use `./gradlew` locally, run `gradle wrapper` once.

## Known limits (be aware before expecting "exact")

* It is an approximation of Apple's animation, not a copy: sizes were read by eye from a
  640x360 video and spring values were estimated, not measured. Icons are drawn with
  paths, not Apple's SF Symbols.
* The overlay sits **above** the status bar, but it can't hide the system clock/icons
  beside the cutout, and it does not appear over the lock screen or secure screens
  (Android blocks overlays there).
* Voice-recording detection reports any app using the mic, including phone calls
  (calls take priority on screen).
* Headphone battery ring is a full ring; Android has no public API for earbud battery.
* Some manufacturers (Xiaomi, Oppo, Samsung battery optimisation) kill background
  services; exclude the app from battery optimisation if the island stops appearing.
