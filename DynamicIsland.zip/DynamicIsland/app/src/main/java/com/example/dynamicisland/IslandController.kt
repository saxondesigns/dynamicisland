package com.example.dynamicisland

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telecom.TelecomManager
import kotlin.math.max

/**
 * Decides WHAT the island shows. Two layers, like iOS:
 *  - transient states (ring/silent, charging, unlock...) show briefly on top of everything;
 *  - background "live activities" (call > recording > timer > music) stay until they end.
 */
class IslandController(private val ctx: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private val window = IslandWindow(ctx)
    private val backgrounds = HashMap<String, IslandState>()
    private val priority = listOf("call", "rec", "timer", "media")
    private var transient: IslandState? = null
    private var expanded = false
    private var lastSig: String? = null

    private val clearTransient = Runnable {
        transient = null
        render()
    }
    private val collapse = Runnable {
        expanded = false
        render()
    }
    private val timerTick = object : Runnable {
        override fun run() {
            val t = backgrounds["timer"] as? IslandState.Timer ?: return
            if (t.pausedLeft != null) return
            if (t.endMs - SystemClock.elapsedRealtime() <= 0) {
                setBackground("timer", null)
                post(IslandState.TimerDone, 4000)
            } else {
                handler.postDelayed(this, 250)
            }
        }
    }

    init {
        window.onTap = { toggleExpand() }
    }

    // ---------- public API used by the service ----------

    fun post(state: IslandState, holdMs: Long) {
        transient = state
        handler.removeCallbacks(clearTransient)
        handler.postDelayed(clearTransient, holdMs)
        render()
    }

    fun setBackground(key: String, state: IslandState?, introExpandMs: Long = 0L) {
        if (state == null) {
            val wasTop = topKey() == key
            backgrounds.remove(key)
            if (wasTop) expanded = false
        } else {
            backgrounds[key] = state
            if (introExpandMs > 0 && topKey() == key) {
                expanded = true
                handler.removeCallbacks(collapse)
                handler.postDelayed(collapse, introExpandMs)
            }
        }
        render()
    }

    fun background(key: String): IslandState? = backgrounds[key]

    fun clearAll() {
        backgrounds.clear()
        transient = null
        expanded = false
        handler.removeCallbacksAndMessages(null)
        render()
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        window.destroy()
    }

    // ---------- timer ----------

    fun startTimer(seconds: Int) {
        val ms = seconds * 1000L
        setBackground("timer", IslandState.Timer(SystemClock.elapsedRealtime() + ms, ms, null))
        handler.removeCallbacks(timerTick)
        handler.post(timerTick)
    }

    fun pauseResumeTimer() {
        val t = backgrounds["timer"] as? IslandState.Timer ?: return
        val now = SystemClock.elapsedRealtime()
        val next = if (t.pausedLeft == null) {
            t.copy(pausedLeft = max(0L, t.endMs - now))
        } else {
            t.copy(endMs = now + t.pausedLeft, pausedLeft = null)
        }
        setBackground("timer", next)
        handler.removeCallbacks(timerTick)
        handler.post(timerTick)
    }

    fun cancelTimer() {
        handler.removeCallbacks(timerTick)
        setBackground("timer", null)
    }

    // ---------- calls ----------

    @SuppressLint("MissingPermission")
    fun answerCall() {
        try {
            ctx.getSystemService(TelecomManager::class.java)?.acceptRingingCall()
        } catch (ignored: SecurityException) {
        }
    }

    @SuppressLint("MissingPermission")
    fun declineCall() {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ctx.getSystemService(TelecomManager::class.java)?.endCall()
            }
        } catch (ignored: SecurityException) {
        }
    }

    // ---------- internals ----------

    private fun topKey(): String? = priority.firstOrNull { backgrounds.containsKey(it) }

    private fun toggleExpand() {
        if (transient != null) return
        val top = topKey()?.let { backgrounds[it] } ?: return
        if (top.alwaysExpanded) return
        expanded = !expanded
        handler.removeCallbacks(collapse)
        if (expanded) handler.postDelayed(collapse, 6000)
        render()
    }

    private fun render() {
        val current = transient ?: topKey()?.let { backgrounds[it] }
        if (current == null) {
            lastSig = null
            window.show(null)
            return
        }
        val exp = transient == null && (expanded || current.alwaysExpanded)
        val sig = current.sig + "|" + exp
        if (sig == lastSig) return
        lastSig = sig
        window.show(Content.build(ctx, current, exp, this))
    }
}
