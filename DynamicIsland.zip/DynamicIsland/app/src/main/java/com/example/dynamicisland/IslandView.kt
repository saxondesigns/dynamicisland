package com.example.dynamicisland

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.max
import kotlin.math.min

/** A finished layout for one island state. Sizes are in pixels. */
class Spec(val w: Int, val h: Int, val r: Float, val view: View)

/**
 * The black pill. Width, height and corner radius are each driven by their own
 * spring, which is what produces the slight overshoot-and-settle that the real
 * Dynamic Island has. Content is clipped to the pill and cross-fades
 * (scale + alpha + blur) while the shape morphs underneath it.
 */
class IslandView(ctx: Context) : FrameLayout(ctx) {
    private var curW = 0f
    private var curH = 0f
    private var curR = 0f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val shape = Path()
    private val bounds = RectF()
    private var content: View? = null

    private fun prop(name: String, get: () -> Float, set: (Float) -> Unit) =
        object : FloatPropertyCompat<IslandView>(name) {
            override fun getValue(o: IslandView): Float = get()
            override fun setValue(o: IslandView, value: Float) {
                set(value)
                o.requestLayout()
                o.invalidate()
            }
        }

    private val springW = SpringAnimation(this, prop("w", { curW }, { curW = it }))
    private val springH = SpringAnimation(this, prop("h", { curH }, { curH = it }))
    private val springR = SpringAnimation(this, prop("r", { curR }, { curR = it }))

    init {
        // SpringAnimation has no spring until one is set, and SpringForce's setters are
        // builder-style (return `this`), so they must be called as methods, not properties.
        springW.setSpring(SpringForce(0f).setStiffness(STIFFNESS).setDampingRatio(DAMPING))
        springH.setSpring(SpringForce(0f).setStiffness(STIFFNESS).setDampingRatio(DAMPING))
        // Slightly softer than the size springs so the corner never "snaps".
        springR.setSpring(SpringForce(0f).setStiffness(STIFFNESS * 0.8f).setDampingRatio(DAMPING))
        for (s in listOf(springW, springH, springR)) {
            s.setMinimumVisibleChange(0.5f) // stop once within half a pixel of the target
        }
        clipChildren = true
    }

    /** Jump to a size with no animation (first appearance). */
    fun snapTo(w: Float, h: Float, r: Float) {
        springW.cancel(); springH.cancel(); springR.cancel()
        curW = w; curH = h; curR = r
        requestLayout(); invalidate()
    }

    fun morphTo(spec: Spec) {
        val old = content
        if (old != null) {
            old.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(120)
                .withEndAction { removeView(old) }.start()
        }
        val nv = spec.view
        nv.alpha = 0f
        nv.scaleX = 0.8f
        nv.scaleY = 0.8f
        addView(nv, FrameLayout.LayoutParams(spec.w, spec.h, Gravity.CENTER))
        content = nv
        nv.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(70).setDuration(260).start()
        blurIn(nv)

        springW.animateToFinalPosition(spec.w.toFloat())
        springH.animateToFinalPosition(spec.h.toFloat())
        springR.animateToFinalPosition(spec.r)
    }

    private fun blurIn(v: View) {
        if (Build.VERSION.SDK_INT < 31) return
        val maxBlur = context.dp(10f)
        ValueAnimator.ofFloat(maxBlur, 0f).apply {
            startDelay = 70
            duration = 260
            addUpdateListener {
                val r = it.animatedValue as Float
                if (r < 0.5f) {
                    v.setRenderEffect(null)
                } else {
                    v.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
                }
            }
            start()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams
            c.measure(
                MeasureSpec.makeMeasureSpec(lp.width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(max(0f, curW).toInt(), max(0f, curH).toInt())
    }

    override fun dispatchDraw(canvas: Canvas) {
        bounds.set(0f, 0f, width.toFloat(), height.toFloat())
        val r = min(max(0f, curR), min(width, height) / 2f)
        shape.reset()
        shape.addRoundRect(bounds, r, r, Path.Direction.CW)
        canvas.drawPath(shape, bg)
        val save = canvas.save()
        canvas.clipPath(shape)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(save)
    }

    companion object {
        // Estimated from the reference video: a quick, lightly under-damped spring.
        const val STIFFNESS = 420f
        const val DAMPING = 0.74f
    }
}
