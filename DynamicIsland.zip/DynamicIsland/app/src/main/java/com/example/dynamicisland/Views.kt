package com.example.dynamicisland

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

enum class Glyph { LOCK, UNLOCK, BELL, BELL_SLASH, MOON, FLASHLIGHT, PHONE, PAUSE, PLAY, PREV, NEXT, CLOSE, HEADPHONES, FACE, CHECK }

/** Vector-style icons drawn on a 24x24 grid so they scale to any size with no resource files. */
class GlyphView(ctx: Context, var glyph: Glyph, var tint: Int) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2f
    }
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        fill.color = tint
        line.color = tint
        line.strokeWidth = 2f
        c.save()
        c.scale(width / 24f, height / 24f)
        when (glyph) {
            Glyph.LOCK -> {
                c.drawRoundRect(5f, 11f, 19f, 21f, 2.5f, 2.5f, fill)
                c.drawArc(8f, 3f, 16f, 13f, 180f, 180f, false, line)
                c.drawLine(8f, 8f, 8f, 11f, line)
                c.drawLine(16f, 8f, 16f, 11f, line)
            }
            Glyph.UNLOCK -> {
                c.drawRoundRect(5f, 11f, 19f, 21f, 2.5f, 2.5f, fill)
                c.drawArc(8f, 1f, 16f, 11f, 180f, 180f, false, line)
                c.drawLine(8f, 6f, 8f, 11f, line)
            }
            Glyph.BELL, Glyph.BELL_SLASH -> {
                path.reset()
                path.moveTo(6f, 10f)
                rect.set(6f, 4f, 18f, 16f)
                path.arcTo(rect, 180f, 180f, false)
                path.lineTo(18f, 15f)
                path.lineTo(20.5f, 17.5f)
                path.lineTo(3.5f, 17.5f)
                path.lineTo(6f, 15f)
                path.close()
                c.drawPath(path, fill)
                c.drawCircle(12f, 20.5f, 2f, fill)
                if (glyph == Glyph.BELL_SLASH) {
                    line.strokeWidth = 2.4f
                    c.drawLine(4f, 3.5f, 20f, 21f, line)
                }
            }
            Glyph.MOON -> {
                val a = Path().apply { addCircle(12f, 12f, 8.5f, Path.Direction.CW) }
                val b = Path().apply { addCircle(17f, 8f, 7.5f, Path.Direction.CW) }
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, fill)
            }
            Glyph.FLASHLIGHT -> {
                path.reset()
                path.moveTo(7.5f, 2f)
                path.lineTo(16.5f, 2f)
                path.lineTo(15f, 8.5f)
                path.lineTo(9f, 8.5f)
                path.close()
                c.drawPath(path, fill)
                c.drawRoundRect(9f, 10f, 15f, 22f, 2f, 2f, fill)
            }
            Glyph.PHONE -> {
                path.reset()
                path.moveTo(6f, 6f)
                path.quadTo(7f, 17f, 18f, 18f)
                line.strokeWidth = 4.6f
                c.drawPath(path, line)
            }
            Glyph.PAUSE -> {
                c.drawRoundRect(6.5f, 5f, 10.5f, 19f, 1.5f, 1.5f, fill)
                c.drawRoundRect(13.5f, 5f, 17.5f, 19f, 1.5f, 1.5f, fill)
            }
            Glyph.PLAY -> {
                path.reset()
                path.moveTo(7f, 4.5f)
                path.lineTo(19f, 12f)
                path.lineTo(7f, 19.5f)
                path.close()
                c.drawPath(path, fill)
            }
            Glyph.PREV -> {
                tri(c, 12f, 5f, 3f, 12f, 12f, 19f)
                tri(c, 21f, 5f, 12f, 12f, 21f, 19f)
            }
            Glyph.NEXT -> {
                tri(c, 3f, 5f, 12f, 12f, 3f, 19f)
                tri(c, 12f, 5f, 21f, 12f, 12f, 19f)
            }
            Glyph.CLOSE -> {
                line.strokeWidth = 2.8f
                c.drawLine(6f, 6f, 18f, 18f, line)
                c.drawLine(18f, 6f, 6f, 18f, line)
            }
            Glyph.HEADPHONES -> {
                c.drawArc(4f, 3f, 20f, 19f, 180f, 180f, false, line)
                c.drawRoundRect(3.5f, 12f, 8f, 20f, 2f, 2f, fill)
                c.drawRoundRect(16f, 12f, 20.5f, 20f, 2f, 2f, fill)
                c.drawLine(4f, 11f, 4f, 13f, line)
                c.drawLine(20f, 11f, 20f, 13f, line)
            }
            Glyph.FACE -> {
                val pts = floatArrayOf(
                    3f, 8f, 3f, 3f, 3f, 3f, 8f, 3f,
                    16f, 3f, 21f, 3f, 21f, 3f, 21f, 8f,
                    3f, 16f, 3f, 21f, 3f, 21f, 8f, 21f,
                    16f, 21f, 21f, 21f, 21f, 16f, 21f, 21f,
                    9f, 9.5f, 9f, 12f, 15f, 9.5f, 15f, 12f
                )
                c.drawLines(pts, line)
                c.drawArc(8.5f, 11f, 15.5f, 17f, 25f, 130f, false, line)
            }
            Glyph.CHECK -> {
                line.strokeWidth = 3f
                path.reset()
                path.moveTo(5f, 12.5f)
                path.lineTo(10f, 17.5f)
                path.lineTo(19f, 7f)
                c.drawPath(path, line)
            }
        }
        c.restore()
    }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.close()
        c.drawPath(path, fill)
    }
}

/** Circular progress ring (timer, AirPods battery, screen-recording countdown). */
class RingView(ctx: Context, var color: Int, var progress: Float = 1f, private val strokeDp: Float = 2.6f) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val r = RectF()

    fun sweepTo(target: Float, ms: Long) {
        ValueAnimator.ofFloat(progress, target).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val sw = context.dp(strokeDp)
        p.strokeWidth = sw
        r.set(sw / 2f, sw / 2f, width - sw / 2f, height - sw / 2f)
        p.color = color
        p.alpha = 70
        c.drawOval(r, p)
        p.color = color
        c.drawArc(r, -90f, 360f * progress.coerceIn(0f, 1f), false, p)
    }
}

/** Battery glyph with a filled level and a charging/low colour. */
class BatteryView(ctx: Context, var level: Int, var color: Int) : View(ctx) {
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val body = RectF()
    private val inner = RectF()
    private val nubRect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sw = context.dp(1.2f)
        val nub = h * 0.2f
        outline.strokeWidth = sw
        outline.color = Color.argb(120, Color.red(color), Color.green(color), Color.blue(color))
        body.set(sw / 2f, sw / 2f, w - nub - 1f - sw / 2f, h - sw / 2f)
        c.drawRoundRect(body, h * 0.3f, h * 0.3f, outline)
        val pad = sw * 1.6f
        val right = pad + max(0f, (body.right - pad * 2f)) * (level.coerceIn(0, 100) / 100f)
        inner.set(pad, pad, max(pad + 1f, right), h - pad)
        fill.color = color
        c.drawRoundRect(inner, h * 0.18f, h * 0.18f, fill)
        nubRect.set(w - nub, h * 0.34f, w, h * 0.66f)
        c.drawRoundRect(nubRect, nub / 2f, nub / 2f, fill)
    }
}

/** Animated vertical bars: call waveform, music equaliser, voice-memo level line. */
class BarsView(
    ctx: Context,
    private val count: Int,
    private val barDp: Float,
    private val gapDp: Float,
    private val color: Int,
    private val animate: Boolean = true
) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var phase = 0f

    init {
        p.color = color
        if (animate) {
            every(50) {
                phase += 0.45f
                invalidate()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val bw = context.dp(barDp)
        val gap = context.dp(gapDp)
        val total = count * bw + (count - 1) * gap
        var x = (width - total) / 2f
        for (i in 0 until count) {
            val a = if (animate) 0.22f + 0.78f * abs(sin(phase + i * 0.85f)) else 0.35f
            val bh = max(bw, height * a)
            c.drawRoundRect(x, (height - bh) / 2f, x + bw, (height + bh) / 2f, bw / 2f, bw / 2f, p)
            x += bw + gap
        }
    }
}

/** Thin scrubber used in the expanded music card. */
class ProgressView(ctx: Context) : View(ctx) {
    var progress = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        p.color = Color.argb(80, 255, 255, 255)
        r.set(0f, 0f, width.toFloat(), h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        r.set(0f, 0f, width * progress.coerceIn(0f, 1f), h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
    }
}
