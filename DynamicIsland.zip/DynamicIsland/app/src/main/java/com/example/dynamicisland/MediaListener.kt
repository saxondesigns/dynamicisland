package com.example.dynamicisland

import android.content.ComponentName
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

/**
 * Android only lets an app read other apps' media sessions if it is an enabled
 * notification listener. We never read notification content; this exists purely
 * to get the permission needed by MediaSessionManager.getActiveSessions().
 */
class MediaListener : NotificationListenerService() {
    private var manager: MediaSessionManager? = null
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> MediaBridge.update(list.orEmpty()) }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java) ?: return
        manager = msm
        val me = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener(sessionsListener, me)
        MediaBridge.update(msm.getActiveSessions(me))
    }

    override fun onListenerDisconnected() {
        manager?.removeOnActiveSessionsChangedListener(sessionsListener)
        manager = null
        MediaBridge.update(emptyList())
    }
}
