package com.example.dynamicisland

import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock

/** Connects the notification-listener's media sessions to the island. Everything runs on the main thread. */
object MediaBridge {
    @Volatile
    var controller: IslandController? = null
        set(value) {
            field = value
            push()
        }

    private var sessions: List<MediaController> = emptyList()
    private var current: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onSessionDestroyed() = pick()
    }

    fun update(list: List<MediaController>) {
        sessions = list
        pick()
    }

    private fun pick() {
        val best = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        if (best?.sessionToken != current?.sessionToken) {
            current?.unregisterCallback(callback)
            current = best
            current?.registerCallback(callback)
        }
        push()
    }

    private fun position(c: MediaController): Long {
        val st = c.playbackState ?: return 0L
        if (st.state != PlaybackState.STATE_PLAYING) return st.position
        val elapsed = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
        return st.position + (elapsed * st.playbackSpeed).toLong()
    }

    private fun push() {
        val island = controller ?: return
        val c = current
        val st = c?.playbackState
        if (c == null || st == null ||
            (st.state != PlaybackState.STATE_PLAYING && st.state != PlaybackState.STATE_PAUSED)
        ) {
            island.setBackground("media", null)
            return
        }
        val md = c.metadata
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        island.setBackground(
            "media",
            IslandState.Media(
                title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
                artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
                art = art,
                playing = st.state == PlaybackState.STATE_PLAYING,
                durationMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
                position = { position(c) },
                controls = c.transportControls
            )
        )
    }
}
