package com.example.dynamicisland

import android.content.Context
import android.view.View
import kotlin.math.roundToInt

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = dp(v).roundToInt()

/**
 * Runs [block] every [ms] while this view is attached to a window, and stops
 * when it is detached. Used for live timers, progress bars and equalizers so
 * nothing keeps running after the island collapses.
 */
fun View.every(ms: Long, block: () -> Unit) {
    val runnable = object : Runnable {
        override fun run() {
            block()
            postDelayed(this, ms)
        }
    }
    addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) {
            runnable.run()
        }

        override fun onViewDetachedFromWindow(v: View) {
            v.removeCallbacks(runnable)
        }
    })
}
