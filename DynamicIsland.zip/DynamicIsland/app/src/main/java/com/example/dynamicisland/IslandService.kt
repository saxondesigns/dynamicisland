package com.example.dynamicisland

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat

/**
 * Foreground service that owns the island and listens to real system events:
 * charging / low battery, ringer switch, Do Not Disturb, flashlight, unlock,
 * Bluetooth audio connect, microphone recording, phone calls, and media sessions.
 */
class IslandService : Service() {
    private lateinit var island: IslandController
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var audio: AudioManager
    private lateinit var cameras: CameraManager
    private lateinit var notifications: NotificationManager

    private var recActive = false
    private val torchStates = HashMap<String, Boolean>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED ->
                    island.post(IslandState.Battery(batteryLevel(), true), 3000)
                Intent.ACTION_BATTERY_LOW ->
                    island.post(IslandState.Battery(batteryLevel(), false), 3500)
                AudioManager.RINGER_MODE_CHANGED_ACTION ->
                    island.post(IslandState.Ringer(audio.ringerMode != AudioManager.RINGER_MODE_NORMAL), 2200)
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED ->
                    island.post(
                        IslandState.Dnd(notifications.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL),
                        2200
                    )
                Intent.ACTION_USER_PRESENT -> island.post(IslandState.Unlock, 1600)
                BluetoothDevice.ACTION_ACL_CONNECTED -> onBluetooth(intent)
                TelephonyManager.ACTION_PHONE_STATE_CHANGED -> onPhone(intent)
            }
        }
    }

    private val recordingCallback = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>) {
            val active = configs.isNotEmpty()
            if (active && !recActive) {
                recActive = true
                island.setBackground("rec", IslandState.VoiceRec(SystemClock.elapsedRealtime()), 2500)
            } else if (!active && recActive) {
                recActive = false
                island.setBackground("rec", null)
            }
        }
    }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            val previous = torchStates.put(cameraId, enabled)
            // The first callback only reports the initial state; don't animate for it.
            if (previous != null && previous != enabled) island.post(IslandState.Torch(enabled), 2200)
        }
    }

    override fun onCreate() {
        super.onCreate()
        island = IslandController(this)
        MediaBridge.controller = island
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        cameras = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        notifications = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        }
        // These are protected system broadcasts, so the receiver must be exported on API 33+.
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        try {
            audio.registerAudioRecordingCallback(recordingCallback, handler)
        } catch (ignored: Exception) {
        }
        try {
            cameras.registerTorchCallback(torchCallback, handler)
        } catch (ignored: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_DEMO -> demo(intent?.getStringExtra(EXTRA_NAME).orEmpty())
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (ignored: Exception) { }
        try { audio.unregisterAudioRecordingCallback(recordingCallback) } catch (ignored: Exception) { }
        try { cameras.unregisterTorchCallback(torchCallback) } catch (ignored: Exception) { }
        MediaBridge.controller = null
        island.destroy()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- real event handlers ----------

    private fun batteryLevel(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level < 0) 0 else level * 100 / scale
    }

    private fun onBluetooth(intent: Intent) {
        val device = IntentCompat.getParcelableExtra(intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        var isAudio = true
        var name = "Headphones"
        try {
            val major = device?.bluetoothClass?.majorDeviceClass
            if (major != null) isAudio = major == BluetoothClass.Device.Major.AUDIO_VIDEO
            name = device?.name ?: name
        } catch (ignored: SecurityException) {
            // BLUETOOTH_CONNECT not granted: show the animation anyway
        }
        if (isAudio) island.post(IslandState.Buds(name), 3500)
    }

    private fun onPhone(intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        // Android sends RINGING twice (with and without the number); only skip an identical repeat
        // if we already have a number-bearing island showing.
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val existing = island.background("call") as? IslandState.Incoming
                if (existing == null || (number != null && existing.caller == "Unknown")) {
                    island.setBackground("call", IslandState.Incoming(lookupName(number)))
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (island.background("call") !is IslandState.Ongoing) {
                    island.setBackground("call", IslandState.Ongoing(SystemClock.elapsedRealtime()))
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE -> island.setBackground("call", null)
        }
    }

    private fun lookupName(number: String?): String {
        if (number.isNullOrBlank()) return "Unknown"
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (ignored: Exception) {
            // no READ_CONTACTS: fall back to the raw number
        }
        return number
    }

    // ---------- foreground notification ----------

    private fun startAsForeground() {
        val channelId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        val stop = android.app.PendingIntent.getService(
            this, 0,
            Intent(this, IslandService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island is running")
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- demo triggers (for states Android cannot detect, and for testing) ----------

    private fun demo(name: String) {
        val now = SystemClock.elapsedRealtime()
        when (name) {
            "unlock" -> island.post(IslandState.Unlock, 1600)
            "ring" -> island.post(IslandState.Ringer(false), 2200)
            "silent" -> island.post(IslandState.Ringer(true), 2200)
            "charging" -> island.post(IslandState.Battery(batteryLevel(), true), 3000)
            "lowbattery" -> island.post(IslandState.Battery(20, false), 3500)
            "dnd_on" -> island.post(IslandState.Dnd(true), 2200)
            "dnd_off" -> island.post(IslandState.Dnd(false), 2200)
            "torch_on" -> island.post(IslandState.Torch(true), 2200)
            "torch_off" -> island.post(IslandState.Torch(false), 2200)
            "faceid" -> island.post(IslandState.FaceId, 2000)
            "buds" -> island.post(IslandState.Buds("Headphones"), 3500)
            "screenrec" -> {
                island.post(IslandState.ScreenRec(0, now), 2900)
                handler.postDelayed({ island.post(IslandState.ScreenRec(1, SystemClock.elapsedRealtime()), 3000) }, 3000)
                handler.postDelayed({ island.post(IslandState.ScreenRec(2, now), 3500) }, 6100)
            }
            "voicerec" -> {
                recActive = true
                island.setBackground("rec", IslandState.VoiceRec(now), 2500)
            }
            "timer" -> island.startTimer(7 * 60)
            "music" -> island.setBackground(
                "media",
                IslandState.Media(
                    "Dynamic Island Demo", "Claude", demoArt(), true, 180_000L,
                    { (SystemClock.elapsedRealtime() - now) % 180_000L }, null
                )
            )
            "incoming" -> island.setBackground("call", IslandState.Incoming("Alex Morgan"))
            "ongoing" -> island.setBackground("call", IslandState.Ongoing(now))
            "clear" -> {
                recActive = false
                island.clearAll()
            }
        }
    }

    private fun demoArt(): Bitmap {
        val bmp = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
        val p = Paint().apply {
            shader = LinearGradient(0f, 0f, 160f, 160f, 0xFFFA586A.toInt(), 0xFF7D3CFF.toInt(), Shader.TileMode.CLAMP)
        }
        Canvas(bmp).drawRect(0f, 0f, 160f, 160f, p)
        return bmp
    }

    companion object {
        const val ACTION_STOP = "com.example.dynamicisland.STOP"
        const val ACTION_DEMO = "com.example.dynamicisland.DEMO"
        const val EXTRA_NAME = "name"
    }
}
