package com.example.dynamicisland

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Owns the system overlay window. The window is only ever as big as the island
 * (plus the spring overshoot), so it never blocks touches on the rest of the
 * status bar, and it is removed completely when the island is idle.
 */
class IslandWindow(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val root = FrameLayout(ctx)
    private val island = IslandView(ctx)
    private var attached = false
    private var winW = 0
    private var winH = 0
    private var token = 0

    var onTap: (() -> Unit)? = null

    // Anchor = where the physical camera hole is, or a sensible default.
    private var centerX = ctx.resources.displayMetrics.widthPixels / 2f
    private var topPx = ctx.dp(11f)
    private var idleW = ctx.dp(126f)
    private var idleH = ctx.dp(37f)

    private val lp = WindowManager.LayoutParams(
        0, 0,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    init {
        root.addView(
            island,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
        )
        island.setOnClickListener { onTap?.invoke() }
    }

    private fun readCutout() {
        centerX = ctx.resources.displayMetrics.widthPixels / 2f
        topPx = ctx.dp(11f)
        idleW = ctx.dp(126f)
        idleH = ctx.dp(37f)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val rect = wm.currentWindowMetrics.windowInsets.displayCutout?.boundingRectTop
                if (rect != null && !rect.isEmpty) {
                    centerX = rect.exactCenterX()
                    topPx = rect.top.toFloat()
                    idleW = rect.width().toFloat()
                    idleH = rect.height().toFloat()
                }
            } catch (ignored: Exception) {
                // fall back to the default anchor
            }
        }
    }

    private fun applyWindow(w: Int, h: Int) {
        winW = w
        winH = h
        val screenW = ctx.resources.displayMetrics.widthPixels
        lp.width = w
        lp.height = h
        lp.x = (centerX - w / 2f).roundToInt().coerceIn(0, max(0, screenW - w))
        lp.y = topPx.roundToInt()
        if (attached) wm.updateViewLayout(root, lp)
    }

    fun show(spec: Spec?) {
        if (spec == null) {
            hide()
            return
        }
        token++
        readCutout()
        // Margin so the spring's overshoot is never clipped by the window edge.
        val pad = ctx.dpi(16f)
        val targetW = spec.w + pad
        val targetH = spec.h + pad
        if (!attached) {
            applyWindow(targetW, targetH)
            wm.addView(root, lp)
            attached = true
            island.snapTo(idleW, idleH, idleH / 2f)
        } else {
            // Grow the window first so the pill is never clipped while it expands/collapses.
            applyWindow(max(winW, targetW), max(winH, targetH))
        }
        island.morphTo(spec)

        val mine = token
        handler.postDelayed({
            if (mine == token && attached) applyWindow(targetW, targetH)
        }, SETTLE_MS)
    }

    private fun hide() {
        if (!attached) return
        token++
        val mine = token
        island.morphTo(Spec(idleW.roundToInt(), idleH.roundToInt(), idleH / 2f, android.view.View(ctx)))
        handler.postDelayed({
            if (mine == token && attached) {
                wm.removeView(root)
                attached = false
            }
        }, SETTLE_MS)
    }

    fun destroy() {
        token++
        handler.removeCallbacksAndMessages(null)
        if (attached) {
            wm.removeView(root)
            attached = false
        }
    }

    companion object {
        const val SETTLE_MS = 600L
    }
}
