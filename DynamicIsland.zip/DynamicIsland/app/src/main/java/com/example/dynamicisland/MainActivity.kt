package com.example.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Setup screen: grant permissions, start/stop the island, and preview every animation. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dpi(16f)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        col.addView(title("Dynamic Island"))
        col.addView(note("1. Grant the permissions, 2. start the island, 3. tap a demo (or just use your phone: charge it, flip the ringer, turn on the flashlight, play music)."))

        col.addView(button("Allow “Display over other apps”") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("Allow media access (notification listener)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("Allow phone, contacts, Bluetooth, notifications") { requestRuntimePermissions() })

        col.addView(button("▶ Start island") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant “Display over other apps” first", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
            }
        })
        col.addView(button("■ Stop island") {
            startService(Intent(this, IslandService::class.java).setAction(IslandService.ACTION_STOP))
        })

        col.addView(title("Demos"))
        val demos = listOf(
            "Unlock" to "unlock", "Ring" to "ring", "Silent" to "silent",
            "Charging" to "charging", "Low battery" to "lowbattery",
            "Screen recording" to "screenrec", "Voice recording" to "voicerec",
            "Face ID" to "faceid", "Headphones connected" to "buds",
            "Music" to "music", "Timer (7:00)" to "timer",
            "Incoming call" to "incoming", "Ongoing call" to "ongoing",
            "Do Not Disturb on" to "dnd_on", "Do Not Disturb off" to "dnd_off",
            "Flashlight on" to "torch_on", "Flashlight off" to "torch_off",
            "Clear everything" to "clear"
        )
        for ((label, key) in demos) {
            col.addView(button(label) { demo(key) })
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun demo(name: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant “Display over other apps” first", Toast.LENGTH_LONG).show()
            return
        }
        ContextCompat.startForegroundService(
            this,
            Intent(this, IslandService::class.java)
                .setAction(IslandService.ACTION_DEMO)
                .putExtra(IslandService.EXTRA_NAME, name)
        )
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun dpi(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 22f
        setTextColor(Color.BLACK)
        setPadding(0, dpi(12f), 0, dpi(8f))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setPadding(0, 0, 0, dpi(8f))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
        visibility = View.VISIBLE
    }
}
