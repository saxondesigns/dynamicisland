package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(this).apply {
            text = "Island setup\n\n1. Allow overlay\n2. Allow notification access\n\nThen: get a notification, play music, or start a timer."
            textSize = 16f
        })
        col.addView(Button(this).apply {
            text = "1. Display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        col.addView(Button(this).apply {
            text = "2. Notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })
        val mins = EditText(this).apply {
            hint = "Timer minutes"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("1")
        }
        col.addView(mins)
        col.addView(Button(this).apply {
            text = "Start timer"
            setOnClickListener {
                val m = mins.text.toString().toIntOrNull() ?: 1
                val svc = IslandService.instance
                if (svc == null) Toast.makeText(this@MainActivity,
                    "Finish steps 1 and 2 first", Toast.LENGTH_SHORT).show()
                else svc.startTimer(m * 60)
            }
        })
        setContentView(col)
    }
}
