package com.example.island

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar
import kotlin.math.abs
import kotlin.math.ceil

class IslandService : NotificationListenerService() {

    companion object { var instance: IslandService? = null }

    private enum class S { IDLE, NOTIF, MUSIC_C, MUSIC_X, TIMER_C, TIMER_X, DUAL, CALL }

    // ---- tweak to match your phone's camera cutout ----
    private val topMarginDp = 8f
    private val pillWidthDp = 126f
    private val pillHeightDp = 36f
    // ---------------------------------------------------

    private val ORANGE = 0xFFFF9F0A.toInt()
    private val GREEN = 0xFF1ED760.toInt()

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var icon: ImageView
    private lateinit var texts: LinearLayout
    private lateinit var title: TextView
    private lateinit var body: TextView
    private lateinit var rightTv: TextView
    private lateinit var controls: LinearLayout
    private lateinit var prev: TextView
    private lateinit var mid: TextView
    private lateinit var next: TextView
    private val bg = GradientDrawable().apply { setColor(0xFF000000.toInt()) }
    private val springInterpolator = Interpolator { input ->
        // Damped spring: ~0.5s response, damping ratio ~0.82. Normalize to settle at 1.
        val zeta = 0.82
        val omega = 12.0
        val t = input.toDouble()
        val wd = omega * kotlin.math.sqrt(1.0 - zeta * zeta)
        val decay = kotlin.math.exp(-zeta * omega * t)
        val displacement = decay * (kotlin.math.cos(wd * t) + (zeta / kotlin.math.sqrt(1.0 - zeta * zeta)) * kotlin.math.sin(wd * t))
        val end = kotlin.math.exp(-zeta * omega) * (kotlin.math.cos(wd) + (zeta / kotlin.math.sqrt(1.0 - zeta * zeta)) * kotlin.math.sin(wd))
        ((1.0 - displacement) / (1.0 - end)).toFloat().coerceIn(-0.05f, 1.08f)
    }
    private var touchDownX = 0f
    private var touchLastX = 0f
    private var touchDownTime = 0L
    private var touchLastTime = 0L
    private var dragging = false
    private var dragVelocity = 0f
    private var demoPosition = 0
    private lateinit var scrubber: SeekBar
    private lateinit var dualActivity: TextView
    private var holdExpanded = false
    private val handler = Handler(Looper.getMainLooper())
    private var anim: ValueAnimator? = null
    private var tap: PendingIntent? = null
    private var attached = false
    private var state = S.IDLE
    private var timerEnd = 0L
    private var mediaDuration = 0L
    private var userSeeking = false
    private var controller: MediaController? = null
    private var demoMusic = false
    private var demoPlaying = true

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun fmt(ms: Long): String {
        val s = ceil(ms / 1000.0).toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun resting(): S = when {
        timerEnd > 0 -> S.TIMER_C
        controller?.playbackState?.state == PlaybackState.STATE_PLAYING -> S.MUSIC_C
        else -> S.IDLE
    }

    private val collapse = Runnable { render(resting()) }

    // ---------- lifecycle ----------

    override fun onListenerConnected() {
        if (attached || !Settings.canDrawOverlays(this)) return
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        icon = ImageView(this).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(8f).toFloat())
                }
            }
        }
        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); setTypeface(typeface, Typeface.BOLD)
            textSize = 14f; maxLines = 1
        }
        body = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt()); textSize = 13f; maxLines = 2
        }
        texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(8f), 0)
            addView(title); addView(body)
        }
        rightTv = TextView(this).apply { textSize = 13f; setTypeface(typeface, Typeface.BOLD) }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(22f), dp(22f)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            addView(rightTv)
        }
        prev = ctl("⏮") { controller?.transportControls?.skipToPrevious() }
        mid = ctl("▶") { onMid() }
        next = ctl("⏭") { controller?.transportControls?.skipToNext() }
        controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER; visibility = View.GONE
            addView(prev); addView(mid); addView(next)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            alpha = 0f
            addView(row, LinearLayout.LayoutParams(-1, -2))
            addView(controls, LinearLayout.LayoutParams(-1, -2))
            scrubber = SeekBar(this@IslandService).apply { max = 180; progress = 35; visibility = View.GONE; setPadding(dp(8f), 0, dp(8f), 0) }
            addView(scrubber, LinearLayout.LayoutParams(-1, dp(30f)))
            dualActivity = TextView(this@IslandService).apply { text = "⏱ 1:30 remaining"; textSize = 12f; setTextColor(0xFFE5E5E7.toInt()); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12f), dp(5f), dp(12f), dp(5f)); background = GradientDrawable().apply { setColor(0xFF1C1C1E.toInt()); cornerRadius = dp(18f).toFloat() }; visibility = View.GONE }
            addView(dualActivity, LinearLayout.LayoutParams(-1, -2))
        }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onLongPress(e: MotionEvent) { holdExpanded = true; expandCurrent() }
            override fun onSingleTapUp(e: MotionEvent): Boolean { onTap(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -500 || abs(vx) > 1000) { onSwipe(); return true }
                return false
            }
        })
        root = LinearLayout(this).apply {
            background = android.graphics.drawable.ColorDrawable(0x00000000)
            setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
            content.background = bg
            addView(content, LinearLayout.LayoutParams(-1, -1))
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { touchDownX = e.rawX; touchLastX = e.rawX; touchDownTime = SystemClock.elapsedRealtime(); touchLastTime = touchDownTime; dragVelocity = 0f; dragging = false; holdExpanded = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchDownX
                        val step = e.rawX - touchLastX
                        val now = SystemClock.elapsedRealtime()
                        val dt = (now - touchLastTime).coerceAtLeast(1L)
                        dragVelocity = step * 1000f / dt
                        touchLastTime = now
                        touchLastX = e.rawX
                        if (abs(dx) > dp(4f)) dragging = true
                        if (dragging) {
                            val stretch = (abs(dx) / dp(700f) + abs(dragVelocity) / 12000f).coerceAtMost(0.14f)
                            v.scaleX = 1f + stretch
                            v.scaleY = 1f - stretch * 0.22f
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (dragging) v.animate().scaleX(1f).scaleY(1f).setDuration((220L - abs(dragVelocity).toLong().coerceAtMost(80L)).coerceAtLeast(140L)).setInterpolator(springInterpolator).start()
                    }
                }
                gd.onTouchEvent(e)
            }
        }
        bg.cornerRadius = dp(pillHeightDp) / 2f

        lp = WindowManager.LayoutParams(
            dp(pillWidthDp + 24f), dp(pillHeightDp + 24f),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topMarginDp) - dp(12f)
        }
        wm.addView(root, lp)
        attached = true
        // Render the persistent idle pill immediately after the overlay attaches.
        render(S.IDLE)

        // hide on lock screen
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        updateVisibility()
        timerEnd = getSharedPreferences("island_timer", MODE_PRIVATE).getLong("end", 0L)
        if (timerEnd > System.currentTimeMillis()) { handler.removeCallbacks(tick); tick.run(); render(S.TIMER_C) } else if (timerEnd != 0L) { timerEnd = 0; getSharedPreferences("island_timer", MODE_PRIVATE).edit().remove("end").apply() }

        // music
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, IslandService::class.java)
            msm.addOnActiveSessionsChangedListener({ list -> pick(list) }, cn)
            pick(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {}
    }

    override fun onListenerDisconnected() {
        if (!attached) return
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        wm.removeView(root)
        attached = false
        instance = null
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateVisibility()
    }

    private fun updateVisibility() {
        if (!attached) return
        val locked = (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
        root.visibility = if (locked) View.GONE else View.VISIBLE
    }

    // ---------- notifications ----------

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!attached || sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        val t = n.extras.getCharSequence(Notification.EXTRA_TITLE) ?: return
        val txt = n.extras.getCharSequence(Notification.EXTRA_TEXT) ?: ""
        handler.post {
            showCard(t, txt, { v ->
                try { v.setImageDrawable(n.smallIcon?.loadDrawable(this)) } catch (_: Exception) {}
            }, n.contentIntent)
        }
    }

    private fun showCard(t: CharSequence, b: CharSequence, ic: (ImageView) -> Unit, pi: PendingIntent?) {
        tap = pi
        title.text = t; body.text = b
        icon.clearColorFilter()
        ic(icon)
        render(S.NOTIF)
    }

    // ---------- music ----------

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(s: PlaybackState?) { handler.post { refreshMusic() } }
        override fun onMetadataChanged(m: MediaMetadata?) { handler.post { refreshMusic() } }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(cb)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(cb)
        refreshMusic()
    }

    private fun refreshMusic() {
        if (!attached) return
        val playing = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
        when (state) {
            S.IDLE -> if (playing) render(S.MUSIC_C)
            S.MUSIC_C, S.MUSIC_X -> if (playing || state == S.MUSIC_X) bindMusic() else render(resting())
            else -> {}
        }
    }

    fun previewNotification(titleText: String = "Test notification", bodyText: String = "Your Island notification preview is working.") {
        handler.post { showCard(titleText, bodyText, { it.setImageResource(android.R.drawable.ic_dialog_info) }, null) }
    }

    fun previewMusic() {
        handler.post { demoMusic = true; demoPlaying = true; demoPosition = 35; render(S.MUSIC_X) }
    }

    fun previewDualActivity() { handler.post { demoMusic = true; demoPlaying = true; timerEnd = System.currentTimeMillis() + 90_000L; render(S.DUAL) } }
    fun previewCallAction() {
        handler.post {
            showCard("Incoming call", "Demo caller · answer/decline preview", { image -> image.setImageResource(android.R.drawable.sym_call_incoming); image.setColorFilter(0xFF30D158.toInt()) }, null)
            render(S.CALL)
        }
    }

    fun stopDemoMusic() {
        handler.post { demoMusic = false; render(resting()) }
    }

    fun expandCurrent() { handler.post { when (state) { S.MUSIC_C -> render(S.MUSIC_X); S.TIMER_C -> render(S.TIMER_X); S.DUAL -> render(S.MUSIC_X); S.CALL -> render(S.CALL); else -> {} } } }
    fun collapseCurrent() { handler.post { render(resting()) } }
    fun dismissIsland() { handler.post { handler.removeCallbacks(collapse); if (timerEnd > 0) cancelTimer() else { demoMusic = false; render(S.IDLE) } } }

    private fun bindMusic() {
        prev.text = "⏮"; next.text = "⏭"; next.visibility = View.VISIBLE
        if (demoMusic) {
            mediaDuration = 180_000L
            scrubber.max = 180
            title.text = "Midnight City"; body.text = "Demo artist · Island preview"
            icon.setImageResource(android.R.drawable.ic_media_play); icon.clearColorFilter()
            rightTv.text = "♫"; rightTv.setTextColor(GREEN)
            prev.visibility = View.VISIBLE; next.visibility = View.VISIBLE
            mid.text = if (demoPlaying) "⏸" else "▶"
            scrubber.progress = demoPosition
            return
        }
        val m = controller?.metadata
        mediaDuration = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        scrubber.max = (mediaDuration / 1000L).toInt().coerceAtLeast(1)
        val position = controller?.playbackState?.position ?: 0L
        if (!userSeeking && mediaDuration > 0) scrubber.progress = (position / 1000L).toInt().coerceIn(0, scrubber.max)
        title.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        body.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        icon.clearColorFilter()
        if (art != null) icon.setImageBitmap(art) else icon.setImageResource(android.R.drawable.ic_media_play)
        rightTv.text = "♫"; rightTv.setTextColor(GREEN)
        prev.visibility = View.VISIBLE; next.visibility = View.VISIBLE
        mid.text = if (controller?.playbackState?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
    }

    private fun onMid() {
        if (state == S.TIMER_X) { cancelTimer(); return }
        if (demoMusic) { demoPlaying = !demoPlaying; bindMusic(); return }
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    // ---------- timer ----------

    fun startTimer(sec: Int) {
        handler.post {
            if (!attached) return@post
            timerEnd = System.currentTimeMillis() + sec * 1000L
            getSharedPreferences("island_timer", MODE_PRIVATE).edit().putLong("end", timerEnd).apply()
            val alarmIntent = Intent(this, TimerAlarmReceiver::class.java).setAction(TimerAlarmReceiver.ACTION_TIMER_DONE)
            val alarmPending = PendingIntent.getBroadcast(this, 901, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            (getSystemService(ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timerEnd, alarmPending)
            handler.removeCallbacks(tick); tick.run()
            if (state == S.IDLE || state == S.MUSIC_C || state == S.MUSIC_X) render(S.TIMER_C)
        }
    }

    private fun cancelTimer() {
        timerEnd = 0; getSharedPreferences("island_timer", MODE_PRIVATE).edit().remove("end").apply(); handler.removeCallbacks(tick);
        val pi = PendingIntent.getBroadcast(this, 901, Intent(this, TimerAlarmReceiver::class.java).setAction(TimerAlarmReceiver.ACTION_TIMER_DONE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi); render(resting())
    }

    private val tick = object : Runnable {
        override fun run() {
            val left = timerEnd - System.currentTimeMillis()
            if (left <= 0) { timerEnd = 0; finishTimer(); return }
            if (state == S.TIMER_C || state == S.TIMER_X || state == S.DUAL) {
                val t = fmt(left); rightTv.text = t; body.text = t; if (state == S.DUAL) dualActivity.text = "⏱  $t remaining"
            }
            handler.postDelayed(this, 250)
        }
    }

    private fun finishTimer() {
        getSharedPreferences("island_timer", MODE_PRIVATE).edit().remove("end").apply()
        val alarmPi = PendingIntent.getBroadcast(this, 901, Intent(this, TimerAlarmReceiver::class.java).setAction(TimerAlarmReceiver.ACTION_TIMER_DONE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(alarmPi)
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
        showCard("Timer", "Time's up", {
            it.setImageResource(android.R.drawable.ic_lock_idle_alarm)
            it.setColorFilter(ORANGE)
        }, null)
    }

    private fun bindTimer() {
        icon.setImageResource(android.R.drawable.ic_lock_idle_alarm)
        icon.setColorFilter(ORANGE)
        val t = fmt(timerEnd - System.currentTimeMillis())
        title.text = "Timer"; body.text = t
        rightTv.text = t; rightTv.setTextColor(ORANGE)
        prev.visibility = View.GONE; next.visibility = View.GONE
        mid.text = "✕ Cancel"
    }

    // ---------- gestures ----------

    private fun onTap() {
        when (state) {
            S.NOTIF -> { try { tap?.send() } catch (_: Exception) {}; render(resting()) }
            S.MUSIC_C -> render(S.MUSIC_X)
            S.MUSIC_X -> render(S.MUSIC_C)
            S.TIMER_C -> render(S.TIMER_X)
            S.TIMER_X -> render(S.TIMER_C)
            S.DUAL -> render(S.MUSIC_X)
            S.CALL -> render(resting())
            S.IDLE -> {}
        }
    }

    private fun onSwipe() { if (state != S.IDLE) render(resting()) }

    // ---------- rendering ----------

    private fun ctl(txt: String, onClick: () -> Unit) = TextView(this).apply {
        text = txt; textSize = 22f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        setPadding(dp(22f), dp(6f), dp(22f), dp(6f))
        setOnClickListener { onClick() }
    }

    private fun render(s: S) {
        state = s
        handler.removeCallbacks(collapse)
        val compact = s == S.IDLE || s == S.MUSIC_C || s == S.TIMER_C
        val full = minOf(dp(360f), resources.displayMetrics.widthPixels - dp(24f))
        val (w, h) = when (s) {
            S.IDLE -> dp(pillWidthDp) to dp(pillHeightDp)
            S.MUSIC_C -> dp(188f) to dp(pillHeightDp)
            S.TIMER_C -> dp(176f) to dp(pillHeightDp)
            S.NOTIF -> full to dp(104f)
            S.MUSIC_X -> full to dp(156f)
            S.TIMER_X -> full to dp(144f)
            S.DUAL -> full to dp(176f)
            S.CALL -> full to dp(126f)
        }
        texts.visibility = if (compact) View.INVISIBLE else View.VISIBLE
        controls.visibility = if (s == S.MUSIC_X || s == S.TIMER_X || s == S.DUAL || s == S.CALL) View.VISIBLE else View.GONE
        prev.setOnClickListener { controller?.transportControls?.skipToPrevious() }; next.setOnClickListener { controller?.transportControls?.skipToNext() }; mid.setOnClickListener { onMid() }
        scrubber.visibility = if (s == S.MUSIC_X || s == S.DUAL) View.VISIBLE else View.GONE
        dualActivity.visibility = if (s == S.DUAL) View.VISIBLE else View.GONE
        scrubber.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar, value: Int, fromUser: Boolean) {
                if (fromUser) {
                    userSeeking = true
                    if (demoMusic) demoPosition = value
                }
            }
            override fun onStartTrackingTouch(seek: SeekBar) {}
            override fun onStopTrackingTouch(seek: SeekBar) {
                if (demoMusic) demoPosition = seek.progress
                else if (mediaDuration > 0L) controller?.transportControls?.seekTo(seek.progress * 1000L)
                userSeeking = false
            }
        })
        rightTv.visibility = if (s == S.MUSIC_C || s == S.TIMER_C) View.VISIBLE else View.GONE
        val sz = when { compact -> 22f; s == S.MUSIC_X -> 56f; else -> 40f }
        (icon.layoutParams as LinearLayout.LayoutParams).apply { width = dp(sz); height = dp(sz) }
        icon.requestLayout()
        if (compact) content.setPadding(dp(12f), 0, dp(12f), 0)
        else content.setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
        when (s) {
            S.MUSIC_C, S.MUSIC_X -> bindMusic()
            S.TIMER_C, S.TIMER_X -> bindTimer()
            S.DUAL -> { bindMusic(); title.text = "Midnight City"; body.text = "Music · Demo artist"; dualActivity.text = "⏱  ${fmt(timerEnd - System.currentTimeMillis())} remaining"; rightTv.visibility = View.GONE; prev.visibility = View.VISIBLE; next.visibility = View.VISIBLE; mid.text = if (demoPlaying) "⏸" else "▶"; controls.visibility = View.VISIBLE }
            S.CALL -> { title.text = "Incoming call"; body.text = "Demo caller · hold to reveal controls"; icon.setImageResource(android.R.drawable.sym_call_incoming); rightTv.text = ""; prev.text = "Decline"; mid.text = "Answer"; next.text = ""; prev.setOnClickListener { render(resting()) }; mid.setOnClickListener { previewNotification("Call connected", "Call action demo (not a real call)") }; next.visibility = View.GONE; controls.visibility = View.VISIBLE }
            else -> {}
        }
        // IDLE is a visible hardware-style pill too; only its inner text is hidden.
        animateTo(w + dp(24f), h + dp(24f), true)
        if (s == S.NOTIF) handler.postDelayed(collapse, 4000)
        else if (s == S.MUSIC_X || s == S.TIMER_X || s == S.DUAL || s == S.CALL) handler.postDelayed(collapse, 8000)
    }

    private fun animateTo(w: Int, h: Int, show: Boolean) {
        anim?.cancel()
        val w0 = lp.width; val h0 = lp.height
        val grow = w > w0 || h > h0
        val animationDuration = if (grow) 520L else 480L
        // Stagger content: fade/scale away before collapse, fade in after the shell reaches ~70%.
        if (!show) {
            content.animate().cancel()
            content.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f)
                .setDuration(140).setInterpolator(DecelerateInterpolator(1.5f)).start()
        } else {
            content.alpha = 0f
            content.scaleX = 0.96f
            content.scaleY = 0.96f
        }
        bg.setStroke(dp(1f), 0x26FFFFFF)
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = animationDuration
            interpolator = springInterpolator
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.width = (w0 + (w - w0) * f).toInt().coerceAtLeast(dp(pillHeightDp))
                lp.height = (h0 + (h - h0) * f).toInt().coerceAtLeast(dp(pillHeightDp))
                // Continuous corner geometry follows the current height.
                bg.cornerRadius = ((lp.height - dp(24f)) * 0.5f).coerceAtMost(dp(42f).toFloat())
                if (show && f >= 0.70f) {
                    val contentF = ((f - 0.70f) / 0.30f).coerceIn(0f, 1f)
                    content.alpha = contentF
                    content.scaleX = 0.96f + 0.04f * contentF
                    content.scaleY = 0.96f + 0.04f * contentF
                }
                if (attached) wm.updateViewLayout(root, lp)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    bg.setStroke(0, 0x00000000)
                    if (show) {
                        content.alpha = 1f; content.scaleX = 1f; content.scaleY = 1f
                    } else {
                        content.alpha = 0f; content.scaleX = 0.94f; content.scaleY = 0.94f
                    }
                }
            })
            start()
        }
    }
}
