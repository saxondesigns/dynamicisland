package com.example.island

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil

class IslandService : NotificationListenerService() {

    companion object { var instance: IslandService? = null }

    private enum class S { IDLE, NOTIF, MUSIC_C, MUSIC_X, TIMER_C, TIMER_X }

    // ---- tweak to match your phone's camera cutout ----
    private val topMarginDp = 10f
    private val pillWidthDp = 120f
    private val pillHeightDp = 34f
    // ---------------------------------------------------

    private val ORANGE = 0xFFFF9F0A.toInt()
    private val GREEN = 0xFF1ED760.toInt()

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var icon: ImageView
    private lateinit var texts: LinearLayout
    private lateinit var title: TextView
    private lateinit var body: TextView
    private lateinit var right: TextView
    private lateinit var controls: LinearLayout
    private lateinit var prev: TextView
    private lateinit var mid: TextView
    private lateinit var next: TextView
    private val bg = GradientDrawable().apply { setColor(0xFF000000.toInt()) }
    private val handler = Handler(Looper.getMainLooper())
    private var anim: ValueAnimator? = null
    private var tap: PendingIntent? = null
    private var attached = false
    private var state = S.IDLE
    private var timerEnd = 0L
    private var controller: MediaController? = null

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun fmt(ms: Long): String {
        val s = ceil(ms / 1000.0).toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun resting(): S = when {
        timerEnd > 0 -> S.TIMER_C
        controller?.playbackState?.state == PlaybackState.STATE_PLAYING -> S.MUSIC_C
        else -> S.IDLE
    }

    private val collapse = Runnable { render(resting()) }

    // ---------- lifecycle ----------

    override fun onListenerConnected() {
        if (attached || !Settings.canDrawOverlays(this)) return
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        icon = ImageView(this).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(8f).toFloat())
                }
            }
        }
        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); setTypeface(typeface, Typeface.BOLD)
            textSize = 14f; maxLines = 1
        }
        body = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt()); textSize = 13f; maxLines = 2
        }
        texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(8f), 0)
            addView(title); addView(body)
        }
        right = TextView(this).apply { textSize = 13f; setTypeface(typeface, Typeface.BOLD) }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(22f), dp(22f)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            addView(right)
        }
        prev = ctl("⏮") { controller?.transportControls?.skipToPrevious() }
        mid = ctl("▶") { onMid() }
        next = ctl("⏭") { controller?.transportControls?.skipToNext() }
        controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER; visibility = View.GONE
            addView(prev); addView(mid); addView(next)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            alpha = 0f
            addView(row, LinearLayout.LayoutParams(-1, -2))
            addView(controls, LinearLayout.LayoutParams(-1, -2))
        }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { onTap(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -500 || abs(vx) > 1000) { onSwipe(); return true }
                return false
            }
        })
        root = LinearLayout(this).apply {
            background = bg
            addView(content, LinearLayout.LayoutParams(-1, -1))
            setOnTouchListener { _, e -> gd.onTouchEvent(e) }
        }
        bg.cornerRadius = dp(pillHeightDp) / 2f

        lp = WindowManager.LayoutParams(
            dp(pillWidthDp), dp(pillHeightDp),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topMarginDp)
        }
        wm.addView(root, lp)
        attached = true

        // hide on lock screen
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        updateVisibility()

        // music
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, IslandService::class.java)
            msm.addOnActiveSessionsChangedListener({ list -> pick(list) }, cn)
            pick(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {}
    }

    override fun onListenerDisconnected() {
        if (!attached) return
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        wm.removeView(root)
        attached = false
        instance = null
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateVisibility()
    }

    private fun updateVisibility() {
        if (!attached) return
        val locked = (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
        root.visibility = if (locked) View.GONE else View.VISIBLE
    }

    // ---------- notifications ----------

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!attached || sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        val t = n.extras.getCharSequence(Notification.EXTRA_TITLE) ?: return
        val txt = n.extras.getCharSequence(Notification.EXTRA_TEXT) ?: ""
        handler.post {
            showCard(t, txt, { v ->
                try { v.setImageDrawable(n.smallIcon?.loadDrawable(this)) } catch (_: Exception) {}
            }, n.contentIntent)
        }
    }

    private fun showCard(t: CharSequence, b: CharSequence, ic: (ImageView) -> Unit, pi: PendingIntent?) {
        tap = pi
        title.text = t; body.text = b
        icon.clearColorFilter()
        ic(icon)
        render(S.NOTIF)
    }

    // ---------- music ----------

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(s: PlaybackState?) { handler.post { refreshMusic() } }
        override fun onMetadataChanged(m: MediaMetadata?) { handler.post { refreshMusic() } }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(cb)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(cb)
        refreshMusic()
    }

    private fun refreshMusic() {
        if (!attached) return
        val playing = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
        when (state) {
            S.IDLE -> if (playing) render(S.MUSIC_C)
            S.MUSIC_C, S.MUSIC_X -> if (playing || state == S.MUSIC_X) bindMusic() else render(resting())
            else -> {}
        }
    }

    private fun bindMusic() {
        val m = controller?.metadata
        title.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        body.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        icon.clearColorFilter()
        if (art != null) icon.setImageBitmap(art) else icon.setImageResource(android.R.drawable.ic_media_play)
        right.text = "♫"; right.setTextColor(GREEN)
        prev.visibility = View.VISIBLE; next.visibility = View.VISIBLE
        mid.text = if (controller?.playbackState?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
    }

    private fun onMid() {
        if (state == S.TIMER_X) { cancelTimer(); return }
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    // ---------- timer ----------

    fun startTimer(sec: Int) {
        handler.post {
            if (!attached) return@post
            timerEnd = SystemClock.elapsedRealtime() + sec * 1000L
            handler.removeCallbacks(tick); tick.run()
            if (state == S.IDLE || state == S.MUSIC_C || state == S.MUSIC_X) render(S.TIMER_C)
        }
    }

    private fun cancelTimer() {
        timerEnd = 0; handler.removeCallbacks(tick); render(resting())
    }

    private val tick = object : Runnable {
        override fun run() {
            val left = timerEnd - SystemClock.elapsedRealtime()
            if (left <= 0) { timerEnd = 0; finishTimer(); return }
            if (state == S.TIMER_C || state == S.TIMER_X) {
                val t = fmt(left); right.text = t; body.text = t
            }
            handler.postDelayed(this, 250)
        }
    }

    private fun finishTimer() {
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
        showCard("Timer", "Time's up", {
            it.setImageResource(android.R.drawable.ic_lock_idle_alarm)
            it.setColorFilter(ORANGE)
        }, null)
    }

    private fun bindTimer() {
        icon.setImageResource(android.R.drawable.ic_lock_idle_alarm)
        icon.setColorFilter(ORANGE)
        val t = fmt(timerEnd - SystemClock.elapsedRealtime())
        title.text = "Timer"; body.text = t
        right.text = t; right.setTextColor(ORANGE)
        prev.visibility = View.GONE; next.visibility = View.GONE
        mid.text = "✕ Cancel"
    }

    // ---------- gestures ----------

    private fun onTap() {
        when (state) {
            S.NOTIF -> { try { tap?.send() } catch (_: Exception) {}; render(resting()) }
            S.MUSIC_C -> render(S.MUSIC_X)
            S.MUSIC_X -> render(S.MUSIC_C)
            S.TIMER_C -> render(S.TIMER_X)
            S.TIMER_X -> render(S.TIMER_C)
            S.IDLE -> {}
        }
    }

    private fun onSwipe() { if (state != S.IDLE) render(resting()) }

    // ---------- rendering ----------

    private fun ctl(txt: String, onClick: () -> Unit) = TextView(this).apply {
        text = txt; textSize = 22f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        setPadding(dp(22f), dp(6f), dp(22f), dp(6f))
        setOnClickListener { onClick() }
    }

    private fun render(s: S) {
        state = s
        handler.removeCallbacks(collapse)
        val compact = s == S.IDLE || s == S.MUSIC_C || s == S.TIMER_C
        val full = minOf(dp(360f), resources.displayMetrics.widthPixels - dp(24f))
        val (w, h) = when (s) {
            S.IDLE -> dp(pillWidthDp) to dp(pillHeightDp)
            S.MUSIC_C, S.TIMER_C -> dp(168f) to dp(pillHeightDp)
            S.NOTIF -> full to dp(84f)
            S.MUSIC_X, S.TIMER_X -> full to dp(136f)
        }
        texts.visibility = if (compact) View.INVISIBLE else View.VISIBLE
        controls.visibility = if (s == S.MUSIC_X || s == S.TIMER_X) View.VISIBLE else View.GONE
        right.visibility = if (s == S.MUSIC_C || s == S.TIMER_C) View.VISIBLE else View.GONE
        val sz = when { compact -> 22f; s == S.MUSIC_X -> 56f; else -> 40f }
        (icon.layoutParams as LinearLayout.LayoutParams).apply { width = dp(sz); height = dp(sz) }
        icon.requestLayout()
        if (compact) content.setPadding(dp(12f), 0, dp(12f), 0)
        else content.setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
        when (s) {
            S.MUSIC_C, S.MUSIC_X -> bindMusic()
            S.TIMER_C, S.TIMER_X -> bindTimer()
            else -> {}
        }
        animateTo(w, h, s != S.IDLE)
        if (s == S.NOTIF) handler.postDelayed(collapse, 4000)
        else if (s == S.MUSIC_X || s == S.TIMER_X) handler.postDelayed(collapse, 6000)
    }

    private fun animateTo(w: Int, h: Int, show: Boolean) {
        anim?.cancel()
        val w0 = lp.width; val h0 = lp.height; val a0 = content.alpha
        val grow = w > w0 || h > h0
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (grow) 500 else 380
            interpolator = if (grow) OvershootInterpolator(1.1f) else DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.width = (w0 + (w - w0) * f).toInt().coerceAtLeast(dp(pillHeightDp))
                lp.height = (h0 + (h - h0) * f).toInt().coerceAtLeast(dp(pillHeightDp))
                bg.cornerRadius = minOf(lp.height / 2f, dp(40f).toFloat())
                val t = it.animatedFraction.coerceIn(0f, 1f)
                content.alpha = a0 + ((if (show) 1f else 0f) - a0) * t
                if (attached) wm.updateViewLayout(root, lp)
            }
            start()
        }
    }
}
