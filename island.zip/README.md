# Island v4 System Events

Android overlay island with notification/media/timer states and previews for system events.

## Build
GitHub Actions workflow: `.github/workflows/android.yml`. It uses Java 17 and Gradle 8.7 to run `gradle assembleDebug`.

## Native event support
- Charging/discharging broadcasts
- Ringer mode changes (silent/vibrate/normal)
- DND interruption-filter changes (when Android broadcasts them to this app)
- Wired headset plug events

## Platform limitations
Android apps cannot generally observe Face ID, AirDrop, or Apple's exact screen-recording state. These are not implemented as real system integrations.
