# Dynamic Island — Premium Edition

An Android overlay that brings a compact, always-visible island and expandable live activities to the top of your screen.

## Highlights
- Premium dark control centre with setup shortcuts and a curated demo gallery.
- Persistent idle pill while the foreground service is running.
- Spring-based width, height and corner morphs with cross-fading content transitions.
- Swipe horizontally across the island to cycle between simultaneous live activities; tap to expand/collapse.
- Media-session playback controls and album art (requires notification access).
- Notification previews (requires notification access; preview text is read transiently and not saved by this app).
- Battery, volume, ringer, Do Not Disturb, flashlight, unlock, Bluetooth audio, microphone activity and phone-call experiences where Android permissions/device support allow them.
- Expandable timer with pause/resume/cancel, plus call controls where the OS permits them.
- Focus-mode demo and multiple-activity demo.
- Navigation and stopwatch preview states for testing the visual language.

## Install/build
1. Put the **contents** of this project in the root of your GitHub repository (the `settings.gradle.kts` file should be at the repository root).
2. Push to GitHub and open **Actions → Android CI**.
3. Download the `dynamic-island-debug-apk` artifact from a successful run.
4. Install the APK on your Android device.
5. Open the app, grant **Display over other apps**, enable **Notification access** for media and notification previews, and grant only the optional system permissions you want to use.
6. Tap **Start island**.

## Controls
- Tap the island to expand or collapse the current live activity.
- Swipe left/right across it to cycle through active activities.
- Use the app's demo gallery to preview the available animations.
- Stop the foreground service from the app or its persistent Android notification.

## Honest limitations
- Navigation and stopwatch are preview/demo states; this app does not calculate routes or integrate directly with Google Maps or another navigation provider.
- Screen-recording and Face ID visuals are illustrative demos, not access to Android's private system UI or biometric internals.
- Android versions, manufacturers, permissions and background-service policies can affect which real system events are available.
- Call answering/ending is restricted by Android and may not work on every device or call type.
- This source package has not been built on a local Android SDK in this environment. Use the included GitHub Actions build to verify compilation and produce the APK.
