package com.example.dynamicisland

import android.graphics.Bitmap
import android.media.session.MediaController
import android.app.PendingIntent

/** Everything the island can show. One class per animation in the reference video. */
sealed class IslandState {
    /** Used to skip re-rendering (and re-animating) when nothing visible changed. */
    open val sig: String get() = toString()
    open val alwaysExpanded: Boolean get() = false

    object Unlock : IslandState()
    data class Ringer(val silent: Boolean) : IslandState()
    data class Battery(val level: Int, val charging: Boolean) : IslandState()
    data class Volume(val level: Int, val max: Int, val stream: String) : IslandState()
    class NotificationPreview(
        val app: String,
        val title: String,
        val message: String,
        val launch: PendingIntent?
    ) : IslandState() {
        override val sig: String get() = "notification|$app|$title|$message"
    }
    data class Dnd(val on: Boolean) : IslandState()
    data class Torch(val on: Boolean) : IslandState()
    object FaceId : IslandState()
    data class Buds(val name: String) : IslandState()

    /** phase 0 = countdown ring, 1 = recording, 2 = "Recording Saved" card. */
    data class ScreenRec(val phase: Int, val startMs: Long) : IslandState()
    data class VoiceRec(val startMs: Long) : IslandState()

    class Media(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val playing: Boolean,
        val durationMs: Long,
        val position: () -> Long,
        val controls: MediaController.TransportControls?
    ) : IslandState() {
        override val sig: String get() = "media|$title|$artist|$playing"
    }

    data class Timer(val endMs: Long, val totalMs: Long, val pausedLeft: Long?) : IslandState()
    object TimerDone : IslandState()

    data class Incoming(val caller: String) : IslandState() {
        override val alwaysExpanded: Boolean get() = true
    }

    data class Ongoing(val startMs: Long) : IslandState()
}
