package com.example.dynamicisland

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Owns the system overlay window. The compact idle pill stays attached while
 * the foreground service runs; live activity content morphs in and out.
 */
class IslandWindow(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val root = FrameLayout(ctx)
    private val island = IslandView(ctx)
    private var attached = false
    private var winW = 0
    private var winH = 0
    private var token = 0

    var onTap: (() -> Unit)? = null
    var onSwipe: (() -> Unit)? = null
    private var downX = 0f
    private var downY = 0f

    // Anchor = where the physical camera hole is, or a sensible default.
    private var centerX = ctx.resources.displayMetrics.widthPixels / 2f
    private var topPx = ctx.dp(11f)
    private var idleW = ctx.dp(126f)
    private var idleH = ctx.dp(37f)

    private val idleSpec: Spec
        get() {
            val label = TextView(ctx).apply {
                text = "·  ·  ·"
                textSize = 10f
                letterSpacing = 0.12f
                setTextColor(Color.rgb(118, 118, 122))
                gravity = Gravity.CENTER
                includeFontPadding = false
                setBackgroundColor(Color.TRANSPARENT)
            }
            return Spec(idleW.roundToInt(), idleH.roundToInt(), idleH / 2f, label)
        }

    private val lp = WindowManager.LayoutParams(
        0, 0,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    init {
        root.addView(
            island,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
        )
        island.setOnClickListener { onTap?.invoke() }
        island.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; false }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) > ctx.dp(48f) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                        onSwipe?.invoke()
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun readCutout() {
        centerX = ctx.resources.displayMetrics.widthPixels / 2f
        topPx = ctx.dp(11f)
        idleW = ctx.dp(126f)
        idleH = ctx.dp(37f)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val rect = wm.currentWindowMetrics.windowInsets.displayCutout?.boundingRectTop
                if (rect != null && !rect.isEmpty) {
                    centerX = rect.exactCenterX()
                    topPx = rect.top.toFloat()
                    idleW = rect.width().toFloat()
                    idleH = rect.height().toFloat()
                }
            } catch (ignored: Exception) {
                // fall back to the default anchor
            }
        }
    }

    private fun applyWindow(w: Int, h: Int) {
        winW = w
        winH = h
        val screenW = ctx.resources.displayMetrics.widthPixels
        lp.width = w
        lp.height = h
        lp.x = (centerX - w / 2f).roundToInt().coerceIn(0, max(0, screenW - w))
        lp.y = topPx.roundToInt()
        if (attached) wm.updateViewLayout(root, lp)
    }

    fun show(requested: Spec?) {
        // Null means compact idle mode, never remove the island.
        readCutout()
        val spec = requested ?: idleSpec
        token++
        val pad = ctx.dpi(16f)
        val targetW = spec.w + pad
        val targetH = spec.h + pad
        if (!attached) {
            applyWindow(targetW, targetH)
            wm.addView(root, lp)
            attached = true
            island.snapTo(idleW, idleH, idleH / 2f)
        } else {
            // Grow first so the spring overshoot is never clipped.
            applyWindow(max(winW, targetW), max(winH, targetH))
        }
        island.morphTo(spec)
        val mine = token
        handler.postDelayed({
            if (mine == token && attached) applyWindow(targetW, targetH)
        }, SETTLE_MS)
    }

    fun destroy() {
        token++
        handler.removeCallbacksAndMessages(null)
        if (attached) {
            wm.removeView(root)
            attached = false
        }
    }

    companion object {
        const val SETTLE_MS = 600L
    }
}
