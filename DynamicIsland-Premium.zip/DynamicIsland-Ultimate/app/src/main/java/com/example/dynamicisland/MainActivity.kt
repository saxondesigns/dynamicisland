package com.example.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Premium, self-contained control centre. No Compose or network dependencies. */
class MainActivity : Activity() {
    private val bg = Color.rgb(8, 9, 13)
    private val panel = Color.rgb(21, 23, 30)
    private val muted = Color.rgb(151, 157, 170)
    private val accent = Color.rgb(116, 101, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildScreen()
    }

    override fun onResume() { super.onResume(); buildScreen() }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = true }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(36))
        }
        scroll.addView(page)
        root.addView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = column().apply {
            addView(label("DYNAMIC ISLAND", 11f, accent, true))
            addView(label("Your phone, reimagined.", 25f, Color.WHITE, true))
            addView(label("A little more magic at the top of your screen.", 13f, muted, false))
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val mark = label("◉", 30f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(accent, 22f)
            setPadding(dp(13), dp(7), dp(13), dp(7))
        }
        top.addView(mark)
        page.addView(top)
        space(page, 20)

        val hero = card(LinearLayout.VERTICAL).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(45, 39, 91), Color.rgb(25, 27, 42), Color.rgb(20, 22, 29))).apply { cornerRadius = dp(25).toFloat() }
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        hero.addView(label("LIVE ISLAND", 11f, Color.rgb(186, 178, 255), true))
        val pill = TextView(this).apply {
            text = "      •   •   •      "
            textSize = 17f
            letterSpacing = .15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.BLACK, 30f)
            setPadding(dp(22), dp(10), dp(22), dp(10))
        }
        val pillRow = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(pill) }
        hero.addView(pillRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(15); bottomMargin = dp(12) })
        hero.addView(label("Always ready. Never in the way.", 15f, Color.WHITE, true))
        hero.addView(label("Tap the island to expand a live activity. Use the demos below to explore the animations.", 12f, Color.rgb(190, 190, 205), false).apply { setPadding(0, dp(5), 0, 0) })
        page.addView(hero)
        space(page, 18)

        section(page, "GET STARTED", "Two permissions unlock the full experience.")
        val permissions = card(LinearLayout.VERTICAL)
        actionRow(permissions, "Display over other apps", "Required to show the island", "Open settings") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        divider(permissions)
        actionRow(permissions, "Notification access", "Media controls and notification previews", "Open settings") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        divider(permissions)
        actionRow(permissions, "System permissions", "Calls, Bluetooth and notifications", "Allow") { requestRuntimePermissions() }
        page.addView(permissions)
        space(page, 14)

        val controls = card(LinearLayout.HORIZONTAL).apply { gravity = Gravity.CENTER_VERTICAL }
        val start = button("Start island", accent) {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Allow Display over other apps first", Toast.LENGTH_LONG).show()
            else ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
        }
        val stop = button("Stop", Color.rgb(54, 57, 68)) {
            startService(Intent(this, IslandService::class.java).setAction(IslandService.ACTION_STOP))
        }
        controls.addView(start, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(7) })
        controls.addView(stop, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(7) })
        page.addView(controls)
        space(page, 23)

        section(page, "TRY THE EXPERIENCES", "Preview the moments the island can surface.")
        val demos = listOf(
            "Unlock" to "unlock", "Silent mode" to "silent", "Ring mode" to "ring",
            "Charging" to "charging", "Low battery" to "lowbattery", "Volume" to "volume",
            "Notification" to "notification", "Screen recording" to "screenrec",
            "Voice recording" to "voicerec", "Face unlock" to "faceid", "Headphones" to "buds",
            "Music player" to "music", "7-minute timer" to "timer", "Incoming call" to "incoming",
            "Active call" to "ongoing", "Navigation preview" to "navigation", "Stopwatch" to "stopwatch",
            "Multiple activities" to "multi", "Focus mode on" to "focus_on", "Focus mode off" to "focus_off",
            "Do Not Disturb" to "dnd_on", "Flashlight" to "torch_on", "Clear island" to "clear"
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        demos.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (title, key) ->
                val b = button(title, panel) { demo(key) }
                row.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                    if (pair.first().first == title) rightMargin = dp(6) else leftMargin = dp(6)
                    bottomMargin = dp(10)
                })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(52), 1f))
            grid.addView(row)
        }
        page.addView(grid)
        space(page, 8)

        val footer = card(LinearLayout.VERTICAL)
        footer.addView(label("MADE TO FEEL NATIVE", 11f, accent, true))
        footer.addView(label("Smooth spring morphs • Live media • Calls • Timers • Focus mode", 13f, Color.WHITE, true).apply { setPadding(0, dp(7), 0, dp(4)) })
        footer.addView(label("Some experiences depend on Android version, device support and permissions. Navigation and stopwatch preview buttons use demo data.", 11f, muted, false))
        page.addView(footer)
        setContentView(root)
    }

    private fun demo(name: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Display over other apps first", Toast.LENGTH_LONG).show(); return
        }
        ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java)
            .setAction(IslandService.ACTION_DEMO).putExtra(IslandService.EXTRA_NAME, name))
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun actionRow(parent: LinearLayout, title: String, detail: String, action: String, click: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(12), dp(13)) }
        val labels = column().apply { addView(label(title, 14f, Color.WHITE, true)); addView(label(detail, 11f, muted, false)) }
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button(action, Color.rgb(49, 51, 65), click))
        parent.addView(row)
    }

    private fun section(parent: LinearLayout, title: String, subtitle: String) {
        parent.addView(label(title, 11f, accent, true))
        parent.addView(label(subtitle, 13f, muted, false).apply { setPadding(0, dp(4), 0, dp(11)) })
    }
    private fun card(content: Int) = LinearLayout(this).apply {
        orientation = content; background = rounded(panel, 21f); setPadding(dp(5), dp(5), dp(5), dp(5))
    }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun label(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private fun button(value: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = value; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = rounded(color, 15f); stateListAnimator = null; setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { click() }
    }
    private fun divider(parent: LinearLayout) { parent.addView(View(this).apply { setBackgroundColor(Color.rgb(42, 44, 53)) }, LinearLayout.LayoutParams(-1, dp(1))) }
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun space(parent: LinearLayout, h: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
}
