package com.example.dynamicisland

import android.content.ComponentName
import android.app.PendingIntent
import android.service.notification.StatusBarNotification
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

/**
 * Android only lets an app read other apps' media sessions if it is an enabled
 * notification listener. We never read notification content; this exists purely
 * to get the permission needed by MediaSessionManager.getActiveSessions().
 */
class MediaListener : NotificationListenerService() {
    private var manager: MediaSessionManager? = null
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> MediaBridge.update(list.orEmpty()) }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java) ?: return
        manager = msm
        val me = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener(sessionsListener, me)
        MediaBridge.update(msm.getActiveSessions(me))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Show a brief preview without retaining notification content. The user
        // explicitly enabled notification access in Android settings.
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and android.app.Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras
        val title = extras?.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
        val message = (
            extras?.getCharSequence(android.app.Notification.EXTRA_BIG_TEXT)
                ?: extras?.getCharSequence(android.app.Notification.EXTRA_TEXT)
            )?.toString().orEmpty()
        if (title.isBlank() && message.isBlank()) return
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            sbn.packageName.substringAfterLast('.')
        }
        MediaBridge.controller?.post(
            IslandState.NotificationPreview(appName, title, message, n.contentIntent),
            4500
        )
    }

    override fun onListenerDisconnected() {
        manager?.removeOnActiveSessionsChangedListener(sessionsListener)
        manager = null
        MediaBridge.update(emptyList())
    }
}
